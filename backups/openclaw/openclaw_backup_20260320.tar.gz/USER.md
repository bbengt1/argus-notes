# USER.md - About Your Human

- **Name:** Brent Bengtson
- **What to call them:** Brent
- **Pronouns:** *(TBD)*
- **Timezone:** America/Chicago (CST)

## Interests & Work

- **3D Printing** — does a lot of it
- **Software Development** — hobby projects
- **AI & Related Tools** — loves working with these

## Access

- GitHub — full access to repos (to help with projects)

## Context

*(More to come as we work together.)*
