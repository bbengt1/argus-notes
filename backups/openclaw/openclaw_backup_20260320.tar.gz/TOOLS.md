# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## Messaging

- **Telegram** — configured and working ✓
  - Brent's chat ID: `8310835415`
  - Username: @BrentBengtson
  - **Gifs/Memes:** Feel free to send when humor fits the moment (gifgrep installed)

## MCP Servers (Docker Gateway)

Access via `mcporter call MCP_DOCKER.<tool>` or the mcp-add/mcp-exec tools.

**Enabled:**
- **playwright** — Browser automation (22 tools)
- **context7** — Library docs lookup (2 tools)
- **paper-search** — Academic papers (23 tools: arXiv, PubMed, bioRxiv, medRxiv, Google Scholar, Semantic Scholar, CrossRef, IACR)

**Available in catalog:**
- **simplechecklist** — Task management with SQLite (had startup issues)
- **arxiv-mcp-server** — arXiv-specific (needs storage_path config)

## Shared Resources

- **argus-notes repo** (`bbengt1/argus-notes`) — our shared collaboration space
  - `/notes/` — general notes
  - `/tasks/` — todos and projects  
  - `/ideas/` — brainstorms and proposals
  - `/multi-model-dev/` — multi-LLM orchestration skill (Claude Code, Codex, Gemini, Grok)
  - `/office365/` — Office 365 integration setup

## 3D Printers

Both are **Snapmaker U1** units running Klipper + Moonraker + Fluidd.

| Printer | IP | Web UI |
|---------|-----|--------|
| Snapmaker U1 #1 | `10.0.1.146` | http://10.0.1.146 |
| Snapmaker U1 #2 | `10.0.1.36` | http://10.0.1.36 |

### Moonraker API

```bash
# Printer status
curl -s "http://10.0.1.146/printer/info"

# Print job status (state, progress, temps)
curl -s "http://10.0.1.146/printer/objects/query?print_stats&virtual_sdcard&heater_bed&extruder"

# States: ready, printing, paused, error, complete
```

### Troubleshooting Log

**2026-02-18 — U1 #1: Starfishtest_PLA_22h34m failed at 74% (layer 166/223)**
- **Symptoms:** Layer shift + spaghetti
- **Likely causes:** Belt tension loosened over long print, possible nozzle collision from warp/lift
- **Action items:** Check X/Y belt tension, inspect bed adhesion, consider reducing speed for 20h+ prints

**2026-02-24 — U1 #2: Feet Qaudrant_PLA_8h10m failed early (~3%, layer 37/1437)**
- **Symptoms:** Filament jam / stuck filament, print cancelled
- **Likely causes:** Extruder gear buildup, partial hotend clog, PTFE tube kink, or aggressive retraction
- **Action items:** Check extruder gear for debris, try cold pull to clear hotend, inspect PTFE tube path, review retraction settings

## Wyze Cameras (Print Monitoring)

- **Streaming:** go2rtc v1.9.14 on ArgusAI server (10.0.1.46), systemd service
- **Web UI:** http://10.0.1.46:1984
- **RTSP Streams:** `rtsp://10.0.1.46:8554/printer-1` and `rtsp://10.0.1.46:8554/printer-2`
- **Credentials:** 🔐 Stored in macOS Keychain (`wyze-email`, `wyze-password`, `wyze-api-id`, `wyze-api-key`)
- **API Key Expiry:** 2027-03-09
- **Cameras:**
  - Printer 1 (U1 #1): Wyze Cam v4, IP 10.0.1.122, MAC 80482C9DA98A, FW 4.52.9.5332 — ✅ Working (DHCP reservation added on March 14, 2026 to prevent IP changes)
  - Printer 2 (U1 #2): Wyze Cam v4, IP 10.0.1.185, MAC 80482C9DA1E0, FW 4.52.9.3415 — ✅ Working (DHCP reservation added on March 14, 2026 to prevent IP changes)
- **Snapshot Script:** `skills/wyze-cam/print_monitor.py`
- **Snapshot command:** `ffmpeg -y -rtsp_transport tcp -i "rtsp://10.0.1.46:8554/printer-1" -frames:v 1 -update 1 output.jpg`
- **Service management:** `ssh root@10.0.1.46 "systemctl restart go2rtc"`

## Obico (3D Print Failure Detection)

- **Web UI:** `http://10.0.1.46:3334`
- **Login:** `root@example.com` / `argus2026!`
- **Containers:** 4x Podman (web, ml_api, redis, tasks) via podman-compose at `/opt/obico-server`
- **Clients:** 2x systemd services (`moonraker-obico-printer1.service`, `moonraker-obico-printer2.service`)
- **Client configs:** `/opt/obico-clients/printer{1,2}/moonraker-obico.cfg`
- **Features:** ML failure detection + auto-pause, temp monitoring, print history

## Known Vehicles
- **Red Tesla Model Y** — Brent's car
- **Red BMW X3 SUV** — Isaac Bengtson's car (Brent's son)
- **Black 2026 Kia Seltos** — Stacey Bengtson's car (Brent's wife)

## ArgusAI (Security Cameras)

- **Endpoint:** `https://10.0.1.46:3000/api/v1` (DNS: argusai.bengtson.local)
- **API Key:** 🔐 Stored in macOS Keychain (service: `argusai-api-key`, account: `argus`). Retrieve: `security find-generic-password -a argus -s argusai-api-key -w`
- **Cameras:** Back Door, Driveway, Front Door (doorbell)
- **Skill:** `skills/argusai/SKILL.md`
- **NLU Script:** `skills/argusai/argusai_nlu.py` (natural language queries)

## UniFi Network and Protect Systems

- **IP Address:** 10.0.1.254
- **UniFi Network Controller:** `https://10.0.1.254:443` (Primary GUI/API)
- **UniFi Protect:** `https://10.0.1.254:7443` (Main REST API)
- **Credentials:** 🔐 Stored in macOS Keychain (services: `unifi-network` and `unifi-protect`, account: `argus`)
- **Status:** Access confirmed on March 14, 2026 (HTTP 200 for Network on 443, HTTP 302 for Protect on 7443 with SSL override for self-signed certificates)
- **Note:** Ready for future automation or integration tasks (e.g., via n8n workflows)

## Home Assistant

- **Endpoint:** `http://10.0.1.233:8123` (DNS: hassio.bengtson.local)
- **Token:** 🔐 Stored in macOS Keychain (service: `homeassistant-token`, account: `argus`). Retrieve: `security find-generic-password -a argus -s homeassistant-token -w`
- **Skill:** `skills/home-assistant/SKILL.md`
- **Control Script:** `skills/home-assistant/ha_control.py`

Key devices:
- **Lights:** Floor Lamp Office 1/2, WLED, Kennel
- **Switches:** Fishtank, Shelf, Entry Light
- **Scenes:** Feed the cats

## n8n Automation Server

- **URL:** `https://n8n.argusai.cc/`
- **API Key:** 🔐 Stored in macOS Keychain (service: `n8n-api-key`, account: `argus`). Retrieve: `security find-generic-password -a argus -s n8n-api-key -w`
- **Use cases:** Redeploy ArgusAI, automation workflows
- **Workflows:** argus-deploy, yolo-mode, Claude Code - Basic Execution

### Triggering Workflows

**argus-deploy** (webhook trigger):
```bash
curl -X POST "https://n8n.argusai.cc/webhook/argus-deploy" \
  -H "Content-Type: application/json" \
  -d '{"source": "openclaw"}'
```

**List workflows** (API):
```bash
curl -H "X-N8N-API-KEY: $N8N_KEY" "https://n8n.argusai.cc/api/v1/workflows"
```

### Auto-Deploy Rule
**When code is pushed to `main` on ArgusAI → trigger the `argus-deploy` workflow**

This deploys the updated ArgusAI to production automatically.

## Moltbook (AI Social Network)

- **Profile:** https://moltbook.com/u/ArgusAI
- **Agent Name:** ArgusAI
- **Credentials:** `~/.config/moltbook/credentials.json`
- **Status:** Pending claim (needs Brent to verify via tweet)
- **Skill docs:** https://moltbook.com/skill.md

## Grok API (xAI)

- **Endpoint:** `https://api.x.ai/v1`
- **API Key:** 🔐 Stored in macOS Keychain (service: `xai-api-key`, account: `argus`). Retrieve: `security find-generic-password -a argus -s xai-api-key -w`
- **Models:** grok-3, grok-3-mini, grok-4-0709, grok-code-fast-1, grok-2-vision-1212
- **Client:** `argus-notes/multi-model-dev/scripts/grok_client.py`

Quick test:
```bash
curl -s -X POST "https://api.x.ai/v1/chat/completions" \
  -H "Authorization: Bearer $GROK_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "grok-3", "messages": [{"role": "user", "content": "Hello"}]}'
```

## Google Workspace

### gws CLI (primary — structured JSON, auto-refresh tokens)
- **Account:** `brent.bengtson@gmail.com`
- **Services:** Gmail, Calendar, Drive, Sheets, Docs, Tasks, Chat
- **Credentials:** `~/.config/gws/credentials.json` (plain, OAuth2)
- **Client Secret:** `~/.config/gws/client_secret.json` (GCP project: gen-lang-client-0983202741)
- **Install:** `npm install -g @googleworkspace/cli`

Quick commands:
```bash
gws gmail users messages list --params '{"userId":"me","maxResults":10,"q":"newer_than:2d"}'
gws calendar events list --params '{"calendarId":"primary","timeMin":"2026-03-10T00:00:00Z","maxResults":10}'
gws drive files list --params '{"pageSize":10,"q":"name contains '\''report'\''"}'
gws sheets spreadsheets values get --params '{"spreadsheetId":"...","range":"Sheet1!A1:D10"}'
```

### gog CLI (legacy — still works, tokens expire weekly)
- **Credentials:** `~/.config/gog/client_secret.json`
- **Skill:** Use built-in `gog` skill
- **Note:** Prefer `gws` for structured JSON; use `gog` when its simpler syntax is convenient

Quick commands:
```bash
gog gmail search 'newer_than:7d' --max 10
gog calendar events primary --from 2026-02-10 --to 2026-02-17
gog drive search "query" --max 10
```

## iMessage Automations

**Safe Send (dedup):** Always use `scripts/imsg-send-safe.sh` instead of `imsg send` directly. It prevents duplicate sends within a 5-minute window (same recipient + same text = skipped). State tracked in `/tmp/imsg-send-dedup.json`.

**Contact Lookup:** `memory/contacts-lookup.json` — phone → name mapping

**Scheduling Workflow:**
- When contacts mention meetings/scheduling in iMessages
- Check Google Calendar (`gog calendar`) for conflicts
- No conflict → Add event automatically
- Conflict → Alert Brent via Telegram
- After adding: Reply to the iMessage with:
  `"See you at <meeting date/time> — sent via Argus, Brent's AI assistant"`

**Note:** Sending requires Automation permission for Messages.app in System Settings → Privacy & Security → Automation

## Coinbase (Crypto)

- **Credentials:** `~/.config/coinbase/cdp_api_key.json` (chmod 600, CDP API key)
- **SDK:** `coinbase-advanced-py` v1.8.2
- **Skill:** `skills/coinbase/SKILL.md`
- **Script:** `skills/coinbase/coinbase_client.py`
- **Commands:** `portfolio`, `price <symbols>`, `movers`, `product <id>`
- **Scope:** Read-only (no trade permissions)
- **Portfolio:** ~$2.65 total (mostly DOGE dust + small change)

## Stock Watchlist

Tracked daily in morning briefing (6 AM):
- **UNH** — UnitedHealth Group
- **AAPL** — Apple
- **TSLA** — Tesla
- **NVDA** — Nvidia

Includes: previous day performance, announcements, trends, X/Twitter buzz.

## Price Tracker

Track item prices and get alerts when they drop below your target.

**How to use:**
- Tell me: "Track [item name] at [URL] and alert me if it drops below $X"
- I'll add it to `memory/price-tracker.json` and check daily at 9 AM
- When price hits target, you get a Telegram alert

**Example:**
"Track Hatchbox PLA filament at [Amazon URL] - alert me below $20"

## ElevenLabs TTS

- **Endpoint:** `https://api.elevenlabs.io/v1`
- **API Key:** 🔐 Stored in macOS Keychain (service: `elevenlabs-api-key`, account: `argus`)
- **Tier:** Free (10,000 chars/month, resets monthly)
- **Primary Voice:** Lily — "Velvety Actress" (British female, voice_id: `pFZP5JQG7iQjIQuC4Bku`)
- **Alt Voice:** Alice — "Clear, Engaging Educator" (British female, voice_id: `Xb7hH8MSUJpSbSDYk0k2`)
- **Script:** `skills/media-gen/elevenlabs_tts.py`
- **Enabled for:** Morning briefings (voice version)

Quick commands:
```bash
python3 skills/media-gen/elevenlabs_tts.py "text" --output speech.mp3
python3 skills/media-gen/elevenlabs_tts.py --usage   # check quota
python3 skills/media-gen/elevenlabs_tts.py --list-voices
```

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.
