#!/usr/bin/env python3
"""3D Print Monitor — Snapshot + status for print monitoring cron job.

Usage:
    python3 print_monitor.py --status           # Check both printers
    python3 print_monitor.py --snap printer-1   # Snapshot one camera
    python3 print_monitor.py --snap all         # Snapshot all cameras
    python3 print_monitor.py --check            # Full check: status + snapshot if printing
"""

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request

WORKSPACE = "/Users/brentbengtson/.openclaw/workspace"
SNAPSHOT_DIR = os.path.join(WORKSPACE, "printer-snapshots")
GO2RTC_HOST = "10.0.1.46"
RTSP_PORT = 8554

CAMERAS = {
    "printer-1": {"name": "Printer 1 (U1 #1)", "moonraker": "10.0.1.146"},
    "printer-2": {"name": "Printer 2 (U1 #2)", "moonraker": "10.0.1.36"},
}


def get_printer_status(printer_ip):
    """Get current print status from Moonraker."""
    try:
        url = f"http://{printer_ip}/printer/objects/query?print_stats&virtual_sdcard&extruder&heater_bed"
        with urllib.request.urlopen(url, timeout=5) as resp:
            data = json.loads(resp.read())
            s = data["result"]["status"]
            ps = s["print_stats"]
            vs = s["virtual_sdcard"]
            ext = s.get("extruder", {})
            bed = s.get("heater_bed", {})
            return {
                "state": ps["state"],
                "filename": ps.get("filename", ""),
                "progress": round(vs["progress"] * 100, 1),
                "print_duration_hrs": round(ps.get("print_duration", 0) / 3600, 1),
                "extruder_temp": round(ext.get("temperature", 0), 1),
                "bed_temp": round(bed.get("temperature", 0), 1),
            }
    except Exception as e:
        return {"state": "unreachable", "error": str(e)}


def take_snapshot(camera_id, output_dir=None):
    """Capture a frame from go2rtc RTSP stream."""
    if output_dir is None:
        output_dir = SNAPSHOT_DIR
    os.makedirs(output_dir, exist_ok=True)

    timestamp = time.strftime("%Y%m%d_%H%M%S")
    filename = f"{camera_id}_{timestamp}.jpg"
    output_path = os.path.join(output_dir, filename)

    rtsp_url = f"rtsp://{GO2RTC_HOST}:{RTSP_PORT}/{camera_id}"

    result = subprocess.run([
        "ffmpeg", "-y",
        "-rtsp_transport", "tcp",
        "-i", rtsp_url,
        "-frames:v", "1",
        "-update", "1",
        output_path
    ], capture_output=True, text=True, timeout=60)

    if os.path.exists(output_path) and os.path.getsize(output_path) > 1000:
        size = os.path.getsize(output_path)
        return {"ok": True, "path": output_path, "size": size, "camera": camera_id}
    else:
        return {"ok": False, "camera": camera_id, "error": result.stderr[-200:] if result.stderr else "unknown"}


def full_check():
    """Check all printers, snapshot any that are printing."""
    results = []
    for cam_id, cam_info in CAMERAS.items():
        status = get_printer_status(cam_info["moonraker"])
        entry = {
            "camera": cam_id,
            "name": cam_info["name"],
            "status": status,
        }

        if status["state"] == "printing":
            snap = take_snapshot(cam_id)
            entry["snapshot"] = snap
        else:
            entry["snapshot"] = None

        results.append(entry)
    return results


def cleanup_old_snapshots(max_age_hours=24):
    """Remove snapshots older than max_age_hours."""
    if not os.path.exists(SNAPSHOT_DIR):
        return
    now = time.time()
    cutoff = now - (max_age_hours * 3600)
    removed = 0
    for f in os.listdir(SNAPSHOT_DIR):
        path = os.path.join(SNAPSHOT_DIR, f)
        if os.path.isfile(path) and os.path.getmtime(path) < cutoff:
            os.remove(path)
            removed += 1
    if removed:
        print(f"Cleaned up {removed} old snapshots")


def main():
    parser = argparse.ArgumentParser(description="3D Print Monitor")
    parser.add_argument("--status", action="store_true", help="Check printer status")
    parser.add_argument("--snap", help="Take snapshot (camera name or 'all')")
    parser.add_argument("--check", action="store_true", help="Full check: status + snap if printing")
    parser.add_argument("--cleanup", action="store_true", help="Remove old snapshots")
    parser.add_argument("--output-dir", default=SNAPSHOT_DIR)

    args = parser.parse_args()

    if args.status:
        for cam_id, cam_info in CAMERAS.items():
            status = get_printer_status(cam_info["moonraker"])
            print(json.dumps({"camera": cam_id, "name": cam_info["name"], **status}))

    elif args.snap:
        if args.snap == "all":
            for cam_id in CAMERAS:
                result = take_snapshot(cam_id, args.output_dir)
                print(json.dumps(result))
        else:
            result = take_snapshot(args.snap, args.output_dir)
            print(json.dumps(result))

    elif args.check:
        cleanup_old_snapshots()
        results = full_check()
        print(json.dumps(results, indent=2))

    elif args.cleanup:
        cleanup_old_snapshots()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
