#!/usr/bin/env python3
"""Wyze Camera Snapshot — Pull snapshots from Wyze cameras via API.

Usage:
    python3 wyze_snapshot.py --list                    # List cameras
    python3 wyze_snapshot.py --snap printer-1           # Snapshot by name
    python3 wyze_snapshot.py --snap all --output-dir /tmp/wyze/  # All cameras
"""

import argparse
import json
import os
import subprocess
import sys
import time


def get_credentials():
    """Get Wyze credentials from macOS Keychain."""
    def kc(service):
        r = subprocess.run(
            ["security", "find-generic-password", "-a", "argus", "-s", service, "-w"],
            capture_output=True, text=True
        )
        return r.stdout.strip()
    
    return {
        "email": kc("wyze-email"),
        "password": kc("wyze-password"),
        "api_id": kc("wyze-api-id"),
        "api_key": kc("wyze-api-key"),
    }


def get_client():
    """Create authenticated Wyze client."""
    from wyze_sdk import Client
    creds = get_credentials()
    
    client = Client(
        email=creds["email"],
        password=creds["password"],
        key_id=creds["api_id"],
        api_key=creds["api_key"],
    )
    return client


def list_cameras():
    """List all Wyze cameras."""
    client = get_client()
    cameras = client.cameras.list()
    
    results = []
    for cam in cameras:
        info = {
            "name": cam.nickname,
            "mac": cam.mac,
            "model": cam.product.model,
            "ip": getattr(cam, 'ip', 'unknown'),
            "is_online": cam.is_online,
        }
        results.append(info)
        print(f"  {cam.nickname}: {cam.product.model} | Online: {cam.is_online} | MAC: {cam.mac}")
    
    return results


def get_thumbnail(camera_name=None, output_dir=None):
    """Get camera thumbnail/snapshot via Wyze API."""
    client = get_client()
    cameras = client.cameras.list()
    
    if not output_dir:
        output_dir = "/tmp/wyze"
    os.makedirs(output_dir, exist_ok=True)
    
    results = []
    for cam in cameras:
        name_lower = cam.nickname.lower().replace(" ", "-")
        
        if camera_name and camera_name != "all":
            search = camera_name.lower().replace(" ", "-")
            if search not in name_lower and name_lower not in search:
                continue
        
        # Get thumbnail URL from camera info
        thumb_url = getattr(cam, 'thumbnail', None)
        if not thumb_url:
            # Try to get latest event thumbnail
            print(f"  {cam.nickname}: No thumbnail URL available, trying event history...")
            try:
                events = client.events.list(device_ids=[cam.mac], limit=1)
                if events:
                    thumb_url = getattr(events[0], 'file_url', None) or getattr(events[0], 'thumbnail', None)
            except Exception as e:
                print(f"  {cam.nickname}: Could not get events: {e}")
        
        if thumb_url:
            output_path = os.path.join(output_dir, f"{name_lower}.jpg")
            result = subprocess.run(
                ["curl", "-sL", "-o", output_path, thumb_url],
                capture_output=True
            )
            
            if os.path.exists(output_path) and os.path.getsize(output_path) > 100:
                size = os.path.getsize(output_path)
                print(f"  {cam.nickname}: Saved to {output_path} ({size} bytes)")
                results.append({"name": cam.nickname, "path": output_path, "size": size})
            else:
                print(f"  {cam.nickname}: Download failed")
        else:
            print(f"  {cam.nickname}: No thumbnail available")
    
    return results


def main():
    parser = argparse.ArgumentParser(description="Wyze Camera Snapshots")
    parser.add_argument("--list", action="store_true", help="List cameras")
    parser.add_argument("--snap", help="Camera name or 'all'")
    parser.add_argument("--output-dir", default="/tmp/wyze", help="Output directory")
    parser.add_argument("--json", action="store_true", help="JSON output")
    
    args = parser.parse_args()
    
    if args.list:
        cameras = list_cameras()
        if args.json:
            print(json.dumps(cameras, indent=2))
    elif args.snap:
        results = get_thumbnail(args.snap, args.output_dir)
        if args.json:
            print(json.dumps(results, indent=2))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
