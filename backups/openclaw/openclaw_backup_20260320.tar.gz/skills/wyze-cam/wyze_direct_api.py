#!/usr/bin/env python3

"""
Wyze Direct API Script for OpenClaw
Purpose: Fetch camera snapshots or status directly from Wyze API without third-party bridges
Author: Argus (OpenClaw Assistant)
Date: March 14, 2026
"""

import os
import requests
import json
import subprocess
import sys
from datetime import datetime

# Function to retrieve credentials from macOS Keychain
def get_keychain_value(service, account):
    try:
        cmd = f"security find-generic-password -a {account} -s {service} -w"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            print(f"Error retrieving {service}: {result.stderr}")
            return None
    except Exception as e:
        print(f"Exception retrieving {service}: {e}")
        return None

# Wyze API endpoints (based on known or reverse-engineered info; subject to change)
WYZE_AUTH_URL = "https://api.wyzecam.com/app/v2/user/login"
WYZE_DEVICE_LIST_URL = "https://api.wyzecam.com/app/v2/device/list"
WYZE_SNAPSHOT_URL = "https://api.wyzecam.com/app/v2/device/get_event_file"

# Headers for API requests (mimicking Wyze app behavior)
HEADERS = {
    "User-Agent": "Wyze/2.0 (iOS;15.0)",
    "Content-Type": "application/json",
    "Accept": "application/json"
}

# Get Wyze credentials from Keychain
WYZE_EMAIL = get_keychain_value("wyze-email", "argus")
WYZE_PASSWORD = get_keychain_value("wyze-password", "argus")
WYZE_API_ID = get_keychain_value("wyze-api-id", "argus")
WYZE_API_KEY = get_keychain_value("wyze-api-key", "argus")

if not all([WYZE_EMAIL, WYZE_PASSWORD, WYZE_API_ID, WYZE_API_KEY]):
    print("Error: Could not retrieve all Wyze credentials from Keychain.")
    sys.exit(1)

# Step 1: Authenticate with Wyze API
def authenticate():
    payload = {
        "email": WYZE_EMAIL,
        "password": WYZE_PASSWORD,
        "app_name": "com.hualai.WyzeCam",
        "app_version": "2.0.0",
        "phone_system_type": "1",
        "phone_id": "iPhone12,1",
        "app_ver": "Wyze_2.0.0",
        "sc": "9f275790cab94a72bd206c8876429f3c",
        "sv": "9f275790cab94a72bd206c8876429f3c",
        "ts": int(datetime.now().timestamp() * 1000)
    }
    try:
        response = requests.post(WYZE_AUTH_URL, json=payload, headers=HEADERS)
        if response.status_code == 200:
            data = response.json()
            if data.get("code") == "1":
                access_token = data.get("data", {}).get("access_token")
                refresh_token = data.get("data", {}).get("refresh_token")
                print("Authentication successful.")
                return access_token, refresh_token
            else:
                print(f"Authentication failed: {data.get('msg', 'Unknown error')}")
                return None, None
        else:
            print(f"Authentication HTTP error: {response.status_code} - {response.text}")
            return None, None
    except Exception as e:
        print(f"Authentication exception: {e}")
        return None, None

# Step 2: List devices (to get camera IDs)
def list_devices(access_token):
    if not access_token:
        print("No access token available for device list.")
        return []
    headers = HEADERS.copy()
    headers["Authorization"] = access_token
    payload = {
        "app_ver": "Wyze_2.0.0",
        "app_version": "2.0.0",
        "phone_id": "iPhone12,1",
        "phone_system_type": "1",
        "sc": "9f275790cab94a72bd206c8876429f3c",
        "sv": "9f275790cab94a72bd206c8876429f3c",
        "ts": int(datetime.now().timestamp() * 1000)
    }
    try:
        response = requests.post(WYZE_DEVICE_LIST_URL, json=payload, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if data.get("code") == "1":
                devices = data.get("data", {}).get("device_list", [])
                print(f"Fetched {len(devices)} devices.")
                return devices
            else:
                print(f"Device list failed: {data.get('msg', 'Unknown error')}")
                return []
        else:
            print(f"Device list HTTP error: {response.status_code} - {response.text}")
            return []
    except Exception as e:
        print(f"Device list exception: {e}")
        return []

# Step 3: Fetch snapshot or event file (placeholder; needs specific camera ID and event)
def fetch_snapshot(access_token, device_id):
    if not access_token:
        print("No access token available for snapshot.")
        return False
    headers = HEADERS.copy()
    headers["Authorization"] = access_token
    payload = {
        "device_mac": device_id,
        "file_type": "1",  # Assuming 1 is for snapshot or recent event
        "app_ver": "Wyze_2.0.0",
        "app_version": "2.0.0",
        "phone_id": "iPhone12,1",
        "phone_system_type": "1",
        "sc": "9f275790cab94a72bd206c8876429f3c",
        "sv": "9f275790cab94a72bd206c8876429f3c",
        "ts": int(datetime.now().timestamp() * 1000)
    }
    try:
        response = requests.post(WYZE_SNAPSHOT_URL, json=payload, headers=headers)
        if response.status_code == 200:
            data = response.json()
            if data.get("code") == "1":
                file_url = data.get("data", {}).get("file_url")
                print(f"Snapshot URL retrieved for {device_id}: {file_url[:50]}...")
                # Download the file (placeholder; needs output path)
                return True
            else:
                print(f"Snapshot fetch failed: {data.get('msg', 'Unknown error')}")
                return False
        else:
            print(f"Snapshot HTTP error: {response.status_code} - {response.text}")
            return False
    except Exception as e:
        print(f"Snapshot exception: {e}")
        return False

# Main execution
def main():
    print("Starting Wyze Direct API interaction...")
    access_token, refresh_token = authenticate()
    if access_token:
        devices = list_devices(access_token)
        for device in devices:
            device_id = device.get("mac", "Unknown")
            device_name = device.get("nickname", "Unnamed Device")
            print(f"Found device: {device_name} (MAC: {device_id})")
            # Optionally fetch snapshot for each device
            # fetch_snapshot(access_token, device_id)
    else:
        print("Authentication failed. Cannot proceed.")

if __name__ == "__main__":
    main()
