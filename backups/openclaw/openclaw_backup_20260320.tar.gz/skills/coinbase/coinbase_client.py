#!/usr/bin/env python3
"""Coinbase Advanced Trade API client for OpenClaw.

Usage:
    python3 coinbase_client.py portfolio          # Holdings + USD values
    python3 coinbase_client.py price BTC ETH SOL  # Price check
    python3 coinbase_client.py movers              # Top 24h movers
    python3 coinbase_client.py product BTC-USD     # Product details
"""

import json
import sys
from pathlib import Path

CREDS_PATH = Path.home() / ".config" / "coinbase" / "cdp_api_key.json"


def get_client():
    from coinbase.rest import RESTClient

    with open(CREDS_PATH) as f:
        creds = json.load(f)
    return RESTClient(api_key=creds["name"], api_secret=creds["privateKey"])


def to_dict(resp):
    """Convert SDK response to a plain dict."""
    if isinstance(resp, dict):
        return resp
    # SDK returns string repr of dict sometimes
    s = str(resp)
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        import ast
        return ast.literal_eval(s)


def cmd_portfolio():
    """Get all holdings with current USD values."""
    client = get_client()

    # Paginate all accounts
    all_accounts = []
    cursor = None
    while True:
        params = {"limit": 250}
        if cursor:
            params["cursor"] = cursor
        resp = client.get_accounts(**params)
        data = to_dict(resp)
        accounts = data.get("accounts", [])
        all_accounts.extend(accounts)
        cursor = data.get("cursor")
        if not cursor:
            break

    # Filter non-zero balances
    holdings = []
    for a in all_accounts:
        bal = a.get("available_balance", {})
        value = float(bal.get("value", 0))
        hold = float(a.get("hold", {}).get("value", 0))
        total = value + hold
        if total > 0.0001:  # skip dust
            holdings.append({
                "currency": bal.get("currency", a.get("currency")),
                "available": value,
                "hold": hold,
                "total": total,
            })

    # Get prices
    stablecoins = {"USD", "USDC", "DAI", "USDT"}
    crypto_holdings = [h for h in holdings if h["currency"] not in stablecoins]
    stable_holdings = [h for h in holdings if h["currency"] in stablecoins]

    product_ids = [f"{h['currency']}-USD" for h in crypto_holdings]

    portfolio = []
    total_usd = 0.0

    if product_ids:
        try:
            bid_ask = client.get_best_bid_ask(product_ids=product_ids)
            data = to_dict(bid_ask)
            pricebooks = data.get("pricebooks", [])

            price_map = {}
            for pb in pricebooks:
                pid = pb.get("product_id", "")
                bids = pb.get("bids", [])
                if bids:
                    price_map[pid] = float(bids[0].get("price", 0))
        except Exception:
            price_map = {}

        for h in crypto_holdings:
            pid = f"{h['currency']}-USD"
            price = price_map.get(pid, 0)
            usd_value = h["total"] * price
            total_usd += usd_value
            portfolio.append({
                "currency": h["currency"],
                "balance": h["total"],
                "price_usd": round(price, 2),
                "value_usd": round(usd_value, 2),
            })

    for h in stable_holdings:
        total_usd += h["total"]
        portfolio.append({
            "currency": h["currency"],
            "balance": round(h["total"], 2),
            "price_usd": 1.0,
            "value_usd": round(h["total"], 2),
        })

    # Sort by value descending
    portfolio.sort(key=lambda x: x["value_usd"], reverse=True)

    result = {
        "portfolio": portfolio,
        "total_value_usd": round(total_usd, 2),
        "num_assets": len(portfolio),
    }
    print(json.dumps(result, indent=2))


def cmd_price(symbols):
    """Get current prices for given symbols."""
    client = get_client()
    product_ids = [f"{s.upper()}-USD" for s in symbols]

    try:
        bid_ask = client.get_best_bid_ask(product_ids=product_ids)
        data = to_dict(bid_ask)
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        return

    prices = []
    for pb in data.get("pricebooks", []):
        pid = pb.get("product_id", "")
        bids = pb.get("bids", [])
        asks = pb.get("asks", [])
        bid = float(bids[0]["price"]) if bids else 0
        ask = float(asks[0]["price"]) if asks else 0
        mid = (bid + ask) / 2 if bid and ask else bid or ask
        prices.append({
            "symbol": pid.replace("-USD", ""),
            "product_id": pid,
            "bid": round(bid, 2),
            "ask": round(ask, 2),
            "mid": round(mid, 2),
        })

    print(json.dumps({"prices": prices}, indent=2))


def cmd_movers():
    """Get top movers by 24h price change."""
    client = get_client()

    # Get popular products
    watchlist = ["BTC-USD", "ETH-USD", "SOL-USD", "DOGE-USD", "ADA-USD",
                 "XRP-USD", "AVAX-USD", "LINK-USD", "DOT-USD", "POL-USD",
                 "SHIB-USD", "UNI-USD", "LTC-USD", "NEAR-USD", "PEPE-USD"]

    movers = []
    for pid in watchlist:
        try:
            product = to_dict(client.get_product(pid))
            price = float(product.get("price", 0))
            pct = float(product.get("price_percentage_change_24h", 0))
            vol = float(product.get("volume_24h", 0))
            movers.append({
                "symbol": pid.replace("-USD", ""),
                "price_usd": round(price, 2),
                "change_24h_pct": round(pct, 2),
                "volume_24h": round(vol, 2),
            })
        except Exception:
            continue

    movers.sort(key=lambda x: abs(x["change_24h_pct"]), reverse=True)
    print(json.dumps({"movers": movers}, indent=2))


def cmd_product(product_id):
    """Get detailed product info."""
    client = get_client()
    try:
        data = to_dict(client.get_product(product_id))
        print(json.dumps(data, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}))


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "portfolio":
        cmd_portfolio()
    elif cmd == "price":
        if len(sys.argv) < 3:
            print("Usage: coinbase_client.py price BTC ETH SOL ...")
            sys.exit(1)
        cmd_price(sys.argv[2:])
    elif cmd == "movers":
        cmd_movers()
    elif cmd == "product":
        if len(sys.argv) < 3:
            print("Usage: coinbase_client.py product BTC-USD")
            sys.exit(1)
        cmd_product(sys.argv[2])
    else:
        print(f"Unknown command: {cmd}")
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
