# Coinbase Skill

Query Coinbase portfolio, prices, and market data via the Advanced Trade API.

## Setup

- **Credentials:** `~/.config/coinbase/cdp_api_key.json` (chmod 600)
- **SDK:** `coinbase-advanced-py` (pip3)
- **Script:** `skills/coinbase/coinbase_client.py`

## Usage

```bash
# Portfolio summary (holdings + USD values)
python3 skills/coinbase/coinbase_client.py portfolio

# Price check for specific coins
python3 skills/coinbase/coinbase_client.py price BTC ETH SOL DOGE

# Top movers (24h)
python3 skills/coinbase/coinbase_client.py movers

# Single product details
python3 skills/coinbase/coinbase_client.py product BTC-USD
```

## Output

All commands output JSON for easy parsing. The `portfolio` command includes:
- Holdings with current USD values
- Total portfolio value
- 24h change per asset (when available)

## Notes

- CDP API key is read-only (no trade permissions)
- Rate limits: ~10 req/sec for private, 25 req/sec for public endpoints
- Prices use best bid/ask (real-time, not delayed)
