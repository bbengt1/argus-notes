#!/usr/bin/env python3
"""ElevenLabs TTS client for Argus.

Usage:
    python3 elevenlabs_tts.py "Text to speak" [--output path.mp3]
    python3 elevenlabs_tts.py "Text to speak" --voice alice
    python3 elevenlabs_tts.py --list-voices
    python3 elevenlabs_tts.py --usage
    echo "Text to speak" | python3 elevenlabs_tts.py --stdin
"""

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error

# Voice profiles for Argus
VOICES = {
    "lily": {
        "voice_id": "pFZP5JQG7iQjIQuC4Bku",
        "name": "Lily - Velvety Actress",
        "description": "Primary Argus voice. British female, warm and rich.",
        "settings": {"stability": 0.5, "similarity_boost": 0.75},
    },
    "alice": {
        "voice_id": "Xb7hH8MSUJpSbSDYk0k2",
        "name": "Alice - Clear, Engaging Educator",
        "description": "Alternative voice. British female, crisp and informative.",
        "settings": {"stability": 0.5, "similarity_boost": 0.75},
    },
}

DEFAULT_VOICE = "lily"
DEFAULT_MODEL = "eleven_multilingual_v2"


def get_api_key():
    """Retrieve ElevenLabs API key from macOS Keychain."""
    result = subprocess.run(
        ["security", "find-generic-password", "-a", "argus", "-s", "elevenlabs-api-key", "-w"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print("Error: Could not retrieve ElevenLabs API key from Keychain", file=sys.stderr)
        sys.exit(1)
    return result.stdout.strip()


def generate_speech(text, voice_name=DEFAULT_VOICE, output=None, model=DEFAULT_MODEL):
    """Generate speech from text using ElevenLabs."""
    api_key = get_api_key()
    
    voice = VOICES.get(voice_name)
    if not voice:
        print(f"Unknown voice '{voice_name}'. Available: {', '.join(VOICES.keys())}", file=sys.stderr)
        sys.exit(1)
    
    voice_id = voice["voice_id"]
    settings = voice["settings"]
    
    out_path = output or f"argus_speech_{int(time.time())}.mp3"
    
    # Use curl to avoid Cloudflare issues
    data = json.dumps({
        "text": text,
        "model_id": model,
        "voice_settings": settings,
    })
    
    result = subprocess.run(
        [
            "curl", "-s", "-X", "POST",
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
            "-H", f"xi-api-key: {api_key}",
            "-H", "Content-Type: application/json",
            "-o", out_path,
            "-w", "%{http_code}",
            "-d", data,
        ],
        capture_output=True, text=True
    )
    
    http_code = result.stdout.strip()
    if http_code != "200":
        # Read error from file
        try:
            with open(out_path, 'r') as f:
                err = f.read()
            print(f"API Error ({http_code}): {err}", file=sys.stderr)
        except Exception:
            print(f"API Error ({http_code})", file=sys.stderr)
        sys.exit(1)
    
    size = os.path.getsize(out_path)
    print(f"Generated: {out_path} ({size} bytes, voice={voice_name})")
    return out_path


def check_usage():
    """Check ElevenLabs API usage/quota."""
    api_key = get_api_key()
    
    result = subprocess.run(
        [
            "curl", "-s",
            "https://api.elevenlabs.io/v1/user/subscription",
            "-H", f"xi-api-key: {api_key}",
        ],
        capture_output=True, text=True
    )
    
    data = json.loads(result.stdout)
    char_count = data.get("character_count", 0)
    char_limit = data.get("character_limit", 0)
    remaining = char_limit - char_count
    tier = data.get("tier", "unknown")
    next_reset = data.get("next_character_count_reset_unix", 0)
    
    reset_str = ""
    if next_reset:
        import datetime
        reset_dt = datetime.datetime.fromtimestamp(next_reset)
        reset_str = f" (resets {reset_dt.strftime('%b %d')})"
    
    print(f"Tier: {tier}")
    print(f"Characters used: {char_count:,} / {char_limit:,}")
    print(f"Remaining: {remaining:,}{reset_str}")
    print(f"Usage: {char_count/char_limit*100:.1f}%")


def list_voices():
    """List configured Argus voice profiles."""
    for name, v in VOICES.items():
        default = " (DEFAULT)" if name == DEFAULT_VOICE else ""
        print(f"  {name}{default}: {v['name']}")
        print(f"    {v['description']}")
        print(f"    voice_id: {v['voice_id']}")
        print()


def main():
    parser = argparse.ArgumentParser(description="ElevenLabs TTS for Argus")
    parser.add_argument("text", nargs="?", help="Text to convert to speech")
    parser.add_argument("--voice", "-v", default=DEFAULT_VOICE, choices=list(VOICES.keys()),
                       help=f"Voice profile (default: {DEFAULT_VOICE})")
    parser.add_argument("--output", "-o", help="Output file path")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="ElevenLabs model ID")
    parser.add_argument("--list-voices", action="store_true", help="List available voices")
    parser.add_argument("--usage", action="store_true", help="Check API usage/quota")
    parser.add_argument("--stdin", action="store_true", help="Read text from stdin")
    
    args = parser.parse_args()
    
    if args.list_voices:
        list_voices()
        return
    
    if args.usage:
        check_usage()
        return
    
    text = args.text
    if args.stdin or (not text and not sys.stdin.isatty()):
        text = sys.stdin.read().strip()
    
    if not text:
        parser.print_help()
        sys.exit(1)
    
    generate_speech(text, args.voice, args.output, args.model)


if __name__ == "__main__":
    main()
