#!/usr/bin/env python3
"""Grok Imagine media generation client for Argus.

Usage:
    python3 grok_media.py image "prompt text" [--model grok-imagine-image-pro] [--output path.jpg]
    python3 grok_media.py video "prompt text" [--output path.mp4] [--poll-interval 10] [--timeout 300]
"""

import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
import urllib.error


def get_api_key():
    """Retrieve xAI API key from macOS Keychain."""
    result = subprocess.run(
        ["security", "find-generic-password", "-a", "argus", "-s", "xai-api-key", "-w"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print("Error: Could not retrieve xAI API key from Keychain", file=sys.stderr)
        sys.exit(1)
    return result.stdout.strip()


def api_request(method, endpoint, api_key, data=None):
    """Make an API request to xAI."""
    url = f"https://api.x.ai/v1/{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": "ArgusAI/1.0",
    }
    
    if data:
        req = urllib.request.Request(url, data=json.dumps(data).encode(), headers=headers, method=method)
    else:
        req = urllib.request.Request(url, headers=headers, method=method)
    
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        try:
            err = json.loads(body)
            print(f"API Error ({e.code}): {err.get('error', body)}", file=sys.stderr)
        except json.JSONDecodeError:
            print(f"API Error ({e.code}): {body}", file=sys.stderr)
        sys.exit(1)


def generate_image(prompt, model="grok-imagine-image", output=None, n=1):
    """Generate an image using Grok Imagine."""
    api_key = get_api_key()
    
    data = {
        "model": model,
        "prompt": prompt,
        "n": n,
    }
    
    result = api_request("POST", "images/generations", api_key, data)
    
    if "data" not in result:
        print(f"Unexpected response: {json.dumps(result)}", file=sys.stderr)
        sys.exit(1)
    
    urls = []
    for i, img in enumerate(result["data"]):
        url = img.get("url", "")
        if url:
            if output:
                out_path = output if n == 1 else f"{os.path.splitext(output)[0]}_{i}{os.path.splitext(output)[1]}"
            else:
                out_path = f"grok_image_{int(time.time())}_{i}.jpg"
            
            # Use curl to avoid Cloudflare blocks
            subprocess.run(["curl", "-sL", "-o", out_path, url], check=True)
            urls.append(out_path)
            print(f"Saved: {out_path}")
    
    return urls


def generate_video(prompt, model="grok-imagine-video", output=None, poll_interval=10, timeout=300,
                    duration=5, aspect_ratio="16:9", resolution="720p"):
    """Generate a video using Grok Imagine (async)."""
    api_key = get_api_key()
    
    data = {
        "model": model,
        "prompt": prompt,
        "duration": duration,
        "aspect_ratio": aspect_ratio,
        "resolution": resolution,
    }
    
    # Submit generation request
    result = api_request("POST", "videos/generations", api_key, data)
    
    request_id = result.get("request_id")
    if not request_id:
        print(f"No request_id in response: {json.dumps(result)}", file=sys.stderr)
        sys.exit(1)
    
    print(f"Video generation submitted: {request_id}")
    print(f"Polling every {poll_interval}s (timeout: {timeout}s)...")
    
    # Poll for completion using /v1/videos/{request_id}
    start = time.time()
    while time.time() - start < timeout:
        time.sleep(poll_interval)
        elapsed = int(time.time() - start)
        
        try:
            poll_result = api_request("GET", f"videos/{request_id}", api_key)
        except SystemExit:
            print(f"  [{elapsed}s] Still processing...")
            continue
        
        status = poll_result.get("status", "")
        print(f"  [{elapsed}s] Status: {status}")
        
        if status == "done":
            video_url = poll_result.get("video", {}).get("url", "")
            if video_url:
                out_path = output or f"grok_video_{int(time.time())}.mp4"
                subprocess.run(["curl", "-sL", "-o", out_path, video_url], check=True)
                print(f"Saved: {out_path}")
                return out_path
        
        if status in ("failed", "error", "expired"):
            print(f"Video generation {status}: {json.dumps(poll_result)}", file=sys.stderr)
            sys.exit(1)
    
    print(f"Timed out after {timeout}s. Request ID: {request_id}", file=sys.stderr)
    print("You can check status later with: grok_media.py video-status <request_id>")
    return None


def check_video_status(request_id):
    """Check status of a video generation request."""
    api_key = get_api_key()
    
    for endpoint in [f"videos/{request_id}"]:
        try:
            result = api_request("GET", endpoint, api_key)
            print(json.dumps(result, indent=2))
            return result
        except SystemExit:
            continue
    
    print(f"Could not retrieve status for {request_id}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(description="Grok Imagine media generation")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Image generation
    img_parser = subparsers.add_parser("image", help="Generate an image")
    img_parser.add_argument("prompt", help="Image generation prompt")
    img_parser.add_argument("--model", default="grok-imagine-image", 
                           choices=["grok-imagine-image", "grok-imagine-image-pro"])
    img_parser.add_argument("--output", "-o", help="Output file path")
    img_parser.add_argument("--count", "-n", type=int, default=1, help="Number of images")
    
    # Video generation
    vid_parser = subparsers.add_parser("video", help="Generate a video")
    vid_parser.add_argument("prompt", help="Video generation prompt")
    vid_parser.add_argument("--model", default="grok-imagine-video")
    vid_parser.add_argument("--output", "-o", help="Output file path")
    vid_parser.add_argument("--poll-interval", type=int, default=10)
    vid_parser.add_argument("--timeout", type=int, default=300)
    vid_parser.add_argument("--duration", type=int, default=5, choices=[5, 10])
    vid_parser.add_argument("--aspect-ratio", default="16:9", choices=["16:9", "9:16", "1:1"])
    vid_parser.add_argument("--resolution", default="720p", choices=["480p", "720p"])
    
    # Video status check
    status_parser = subparsers.add_parser("video-status", help="Check video generation status")
    status_parser.add_argument("request_id", help="Video generation request ID")
    
    args = parser.parse_args()
    
    if args.command == "image":
        generate_image(args.prompt, args.model, args.output, args.count)
    elif args.command == "video":
        generate_video(args.prompt, args.model, args.output, args.poll_interval, args.timeout,
                       args.duration, args.aspect_ratio, args.resolution)
    elif args.command == "video-status":
        check_video_status(args.request_id)


if __name__ == "__main__":
    main()
