# Media Generation Skill

Generate images, video, and audio using AI services.

## Tools

### Grok Imagine (Images & Video)
**Script:** `skills/media-gen/grok_media.py`
**API Key:** macOS Keychain (`xai-api-key`)

#### Image Generation
```bash
python3 skills/media-gen/grok_media.py image "prompt" --output path.jpg
python3 skills/media-gen/grok_media.py image "prompt" --model grok-imagine-image-pro --output path.jpg
```

Models:
- `grok-imagine-image` — standard (fast, good quality)
- `grok-imagine-image-pro` — higher quality

#### Video Generation
```bash
python3 skills/media-gen/grok_media.py video "prompt" --output path.mp4
python3 skills/media-gen/grok_media.py video "prompt" --duration 10 --aspect-ratio 16:9 --resolution 720p --output path.mp4
```

Options:
- `--duration`: 5 or 10 seconds
- `--aspect-ratio`: 16:9, 9:16, 1:1
- `--resolution`: 480p, 720p
- `--poll-interval`: seconds between status checks (default 10)
- `--timeout`: max wait time in seconds (default 300)

Video generation is async — script handles polling automatically. Typical generation time: 15-30 seconds.

#### Check Video Status
```bash
python3 skills/media-gen/grok_media.py video-status <request_id>
```

### ElevenLabs TTS (Primary)
**Script:** `skills/media-gen/elevenlabs_tts.py`
**API Key:** macOS Keychain (`elevenlabs-api-key`)
**Primary Voice:** Lily (British female, warm/rich)
**Alt Voice:** Alice (British female, crisp/informative)

```bash
python3 skills/media-gen/elevenlabs_tts.py "text to speak" --output speech.mp3
python3 skills/media-gen/elevenlabs_tts.py "text" --voice alice --output speech.mp3
python3 skills/media-gen/elevenlabs_tts.py --usage    # check character quota
python3 skills/media-gen/elevenlabs_tts.py --list-voices
echo "long text" | python3 skills/media-gen/elevenlabs_tts.py --stdin --output speech.mp3
```

**Quota:** Free tier = 10,000 chars/month. A briefing is ~800-1000 chars spoken.

### Built-in TTS (Fallback)
Use the built-in `tts` tool in OpenClaw when ElevenLabs quota is exhausted:
```
tts(text="Hello!", channel="telegram")
```

### Whisper (Speech-to-Text)
See `openai-whisper` skill for transcription.

### Video Composer (ffmpeg + Pillow)
**Script:** `skills/media-gen/video_composer.py`
**Dependencies:** ffmpeg, Pillow (text rendered as images since homebrew ffmpeg lacks drawtext)

```bash
# Slideshow from images
python3 skills/media-gen/video_composer.py slideshow --images img1.jpg img2.jpg --audio narration.mp3 --output video.mp4

# Image with text overlay
python3 skills/media-gen/video_composer.py overlay --image bg.jpg --text "Hello" --audio speech.mp3 --output clip.mp4

# Stitch clips together
python3 skills/media-gen/video_composer.py stitch --clips clip1.mp4 clip2.mp4 --output final.mp4

# Title card (text on dark background)
python3 skills/media-gen/video_composer.py title "Title Text" --subtitle "Subtitle" --output title.mp4

# Full briefing video (sections + narration)
python3 skills/media-gen/video_composer.py briefing --sections-json sections.json --audio narration.mp3 --output briefing.mp4
```

### Camera Recap (ArgusAI)
**Script:** `skills/media-gen/camera_recap.py`
Pulls event thumbnails from ArgusAI and composes a security recap video.

```bash
# Basic recap (slideshow of thumbnails)
python3 skills/media-gen/camera_recap.py --hours 24 --output recap.mp4

# Narrated recap (uses ElevenLabs)
python3 skills/media-gen/camera_recap.py --hours 24 --narrate --output recap.mp4

# Just download stills
python3 skills/media-gen/camera_recap.py --hours 24 --images-only --output-dir /tmp/stills/
```

## Notes
- Cloudflare blocks Python urllib — script uses curl for downloads
- Generated files should be saved to workspace for Telegram delivery
- Telegram limits: 50MB for bot files, voice must be OGG/Opus
- Video notes (circular) max 1 min, 640x640

## Future
- [x] ElevenLabs TTS with Lily voice (British female)
- [x] ffmpeg + Pillow compositing pipeline (images + audio + text → video)
- [x] Camera clip compilation from ArgusAI (thumbnails + optional narration)
- [x] Auto-TTS for briefings (enabled)
- [x] Morning briefing video generation
- [ ] More voice profiles (serious, storytelling, unhinged)
- [ ] Voice conversation mode (bidirectional)
