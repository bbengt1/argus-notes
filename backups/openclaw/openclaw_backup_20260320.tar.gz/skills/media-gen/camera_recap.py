#!/usr/bin/env python3
"""ArgusAI Camera Recap — Pull event thumbnails and compose a security recap video.

Usage:
    python3 camera_recap.py --hours 24 --output recap.mp4
    python3 camera_recap.py --hours 12 --narrate --output recap.mp4
    python3 camera_recap.py --hours 24 --images-only --output-dir /tmp/stills/
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import time

WORKSPACE = "/Users/brentbengtson/.openclaw/workspace"
ARGUSAI_SCRIPT = os.path.join(WORKSPACE, "skills/argusai/argusai_nlu.py")
ELEVENLABS_SCRIPT = os.path.join(WORKSPACE, "skills/media-gen/elevenlabs_tts.py")
COMPOSER_SCRIPT = os.path.join(WORKSPACE, "skills/media-gen/video_composer.py")


def get_api_key():
    """Get ArgusAI API key from Keychain."""
    result = subprocess.run(
        ["security", "find-generic-password", "-a", "argus", "-s", "argusai-api-key", "-w"],
        capture_output=True, text=True
    )
    return result.stdout.strip()


def fetch_events(hours=24, limit=20):
    """Fetch recent events from ArgusAI API."""
    import urllib.request
    import ssl
    
    api_key = get_api_key()
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    url = f"https://10.0.1.46:3000/api/v1/events?hours={hours}&limit={limit}"
    req = urllib.request.Request(url, headers={"x-api-key": api_key})
    
    with urllib.request.urlopen(req, context=ctx) as resp:
        data = json.loads(resp.read().decode())
        # API returns {events: [...], total_count, ...}
        if isinstance(data, dict) and "events" in data:
            return data["events"]
        return data


def fetch_event_detail(event_id):
    """Fetch full event detail from ArgusAI."""
    import urllib.request
    import ssl
    
    api_key = get_api_key()
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    url = f"https://10.0.1.46:3000/api/v1/events/{event_id}"
    req = urllib.request.Request(url, headers={"x-api-key": api_key})
    
    with urllib.request.urlopen(req, context=ctx) as resp:
        return json.loads(resp.read().decode())


def fetch_thumbnail(event, output_path):
    """Fetch event thumbnail from ArgusAI using thumbnail_path."""
    api_key = get_api_key()
    
    # Get thumbnail path from event detail or event itself
    thumb_path = event.get("thumbnail_path", "")
    if not thumb_path:
        return False
    
    # thumbnail_path is relative API path like /api/v1/thumbnails/...
    url = f"https://10.0.1.46:3000{thumb_path}"
    
    result = subprocess.run([
        "curl", "-sk",
        url,
        "-H", f"x-api-key: {api_key}",
        "-o", output_path
    ], capture_output=True)
    
    if os.path.exists(output_path) and os.path.getsize(output_path) > 100:
        # Verify it's actually an image
        file_check = subprocess.run(["file", output_path], capture_output=True, text=True)
        return "image" in file_check.stdout.lower() or "JPEG" in file_check.stdout
    return False


def generate_recap(hours=24, output="recap.mp4", narrate=False, max_events=10, images_only=False, output_dir=None):
    """Generate a security camera recap video."""
    print(f"Fetching events from last {hours} hours...")
    events = fetch_events(hours, limit=max_events)
    
    if not events:
        print("No events found in the specified time range.")
        return None
    
    print(f"Found {len(events)} events")
    
    tmp_dir = output_dir or tempfile.mkdtemp(prefix="argus_recap_")
    thumbnails = []
    event_descriptions = []
    
    for i, event in enumerate(events[:max_events]):
        event_id = event.get("id", event.get("_id", ""))
        camera = event.get("camera", event.get("camera_name", "Unknown"))
        description = event.get("description", event.get("summary", "Activity detected"))
        timestamp = event.get("timestamp", event.get("created_at", ""))
        
        # Get full event detail for thumbnail_path if not present
        if "thumbnail_path" not in event:
            try:
                event = fetch_event_detail(event_id)
            except Exception as e:
                print(f"  [{i+1}] Could not fetch detail: {e}")
        
        # Fetch thumbnail
        thumb_path = os.path.join(tmp_dir, f"thumb_{i:03d}.jpg")
        if fetch_thumbnail(event, thumb_path):
            thumbnails.append(thumb_path)
            event_descriptions.append({
                "camera": camera,
                "description": description[:80],
                "timestamp": timestamp,
                "image": thumb_path
            })
            print(f"  [{i+1}] {camera}: {description[:60]}...")
        else:
            print(f"  [{i+1}] {camera}: thumbnail unavailable")
    
    if images_only:
        print(f"Thumbnails saved to: {tmp_dir}")
        return tmp_dir
    
    if not thumbnails:
        print("No thumbnails available for video generation.")
        return None
    
    # Build sections for video composer
    sections = []
    for desc in event_descriptions:
        sections.append({
            "title": desc["camera"],
            "text": desc["description"],
            "image": desc["image"]
        })
    
    # Generate narration if requested
    audio_path = None
    if narrate:
        narration_text = f"Security recap for the last {hours} hours. "
        for desc in event_descriptions:
            narration_text += f"{desc['camera']}: {desc['description']}. "
        narration_text += "End of recap."
        
        audio_path = os.path.join(tmp_dir, "narration.mp3")
        subprocess.run([
            sys.executable, ELEVENLABS_SCRIPT,
            narration_text[:1000],  # Cap at 1000 chars for quota
            "--output", audio_path
        ], capture_output=True)
        
        if not os.path.exists(audio_path) or os.path.getsize(audio_path) == 0:
            print("Narration generation failed, creating video without audio")
            audio_path = None
    
    if audio_path:
        # Use briefing composer with audio
        sections_json = os.path.join(tmp_dir, "sections.json")
        with open(sections_json, "w") as f:
            json.dump(sections, f)
        
        subprocess.run([
            sys.executable, COMPOSER_SCRIPT, "briefing",
            "--sections-json", sections_json,
            "--audio", audio_path,
            "--output", output
        ])
    else:
        # Slideshow without audio
        subprocess.run([
            sys.executable, COMPOSER_SCRIPT, "slideshow",
            "--images"] + thumbnails + [
            "--output", output,
            "--duration", "4",
            "--title", f"Security Recap ({hours}h)"
        ])
    
    if os.path.exists(output):
        size = os.path.getsize(output)
        print(f"Recap saved: {output} ({size/1024/1024:.1f}MB)")
        return output
    
    return None


def main():
    parser = argparse.ArgumentParser(description="ArgusAI Camera Recap")
    parser.add_argument("--hours", type=int, default=24, help="Hours to look back")
    parser.add_argument("--output", "-o", default="recap.mp4", help="Output file")
    parser.add_argument("--narrate", action="store_true", help="Add voice narration (uses ElevenLabs)")
    parser.add_argument("--max-events", type=int, default=10, help="Max events to include")
    parser.add_argument("--images-only", action="store_true", help="Just save thumbnails")
    parser.add_argument("--output-dir", help="Directory for images-only mode")
    
    args = parser.parse_args()
    generate_recap(args.hours, args.output, args.narrate, args.max_events,
                   args.images_only, args.output_dir)


if __name__ == "__main__":
    main()
