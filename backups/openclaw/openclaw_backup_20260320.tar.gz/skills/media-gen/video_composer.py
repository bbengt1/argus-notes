#!/usr/bin/env python3
"""Video compositing pipeline for Argus.

Uses Pillow for text rendering (since homebrew ffmpeg lacks drawtext)
and ffmpeg for video encoding/stitching.

Usage:
    python3 video_composer.py slideshow --images img1.jpg img2.jpg --audio narration.mp3 --output briefing.mp4
    python3 video_composer.py overlay --image bg.jpg --text "Hello World" --audio speech.mp3 --output clip.mp4
    python3 video_composer.py stitch --clips clip1.mp4 clip2.mp4 --output final.mp4
    python3 video_composer.py title "Argus Daily Briefing" --output title.mp4
    python3 video_composer.py briefing --sections-json sections.json --audio narration.mp3 --output briefing.mp4
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import time
from PIL import Image, ImageDraw, ImageFont


WORKSPACE = "/Users/brentbengtson/.openclaw/workspace"
RESOLUTION = (1280, 720)

# Try to find a good font
FONT_CANDIDATES = [
    "/System/Library/Fonts/Helvetica.ttc",
    "/System/Library/Fonts/SFNSMono.ttf",
    "/System/Library/Fonts/SFNS.ttf",
    "/Library/Fonts/Arial.ttf",
]


def get_font(size=36):
    """Get a PIL font at the specified size."""
    for path in FONT_CANDIDATES:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    return ImageFont.load_default()


def run_ffmpeg(args, check=True):
    """Run ffmpeg command."""
    cmd = ["ffmpeg", "-y"] + args
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        print(f"ffmpeg error: {result.stderr[-500:]}", file=sys.stderr)
        sys.exit(1)
    return result


def get_audio_duration(path):
    """Get duration of an audio file in seconds."""
    result = subprocess.run(
        ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", path],
        capture_output=True, text=True
    )
    data = json.loads(result.stdout)
    return float(data["format"]["duration"])


def render_text_image(text, output_path, size=RESOLUTION, bg_color=(26, 26, 46),
                      text_color=(255, 255, 255), font_size=36, position="center",
                      subtitle=None, subtitle_size=24):
    """Render text onto a solid background image using Pillow."""
    img = Image.new("RGB", size, bg_color)
    draw = ImageDraw.Draw(img)
    font = get_font(font_size)
    
    # Get text bounding box
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    
    # Position
    if position == "center":
        x = (size[0] - tw) // 2
        y = (size[1] - th) // 2 - (20 if subtitle else 0)
    elif position == "top":
        x = (size[0] - tw) // 2
        y = 30
    elif position == "bottom":
        x = (size[0] - tw) // 2
        y = size[1] - th - 60
    else:
        x = (size[0] - tw) // 2
        y = (size[1] - th) // 2
    
    # Draw text with shadow
    draw.text((x + 2, y + 2), text, fill=(0, 0, 0), font=font)
    draw.text((x, y), text, fill=text_color, font=font)
    
    # Subtitle
    if subtitle:
        sub_font = get_font(subtitle_size)
        sub_bbox = draw.textbbox((0, 0), subtitle, font=sub_font)
        stw = sub_bbox[2] - sub_bbox[0]
        sx = (size[0] - stw) // 2
        sy = y + th + 15
        sub_color = (*text_color[:3], 180) if len(text_color) == 4 else (200, 200, 200)
        draw.text((sx, sy), subtitle, fill=sub_color, font=sub_font)
    
    img.save(output_path, quality=95)
    return output_path


def render_overlay_image(bg_path, text, output_path, position="bottom",
                         font_size=28, text_color=(255, 255, 255)):
    """Overlay text onto an existing image using Pillow."""
    img = Image.open(bg_path).convert("RGB")
    img = img.resize(RESOLUTION, Image.LANCZOS)
    
    # Semi-transparent overlay bar
    overlay = Image.new("RGBA", RESOLUTION, (0, 0, 0, 0))
    overlay_draw = ImageDraw.Draw(overlay)
    
    font = get_font(font_size)
    bbox = overlay_draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    
    # Draw dark bar behind text
    padding = 15
    if position == "bottom":
        bar_y = RESOLUTION[1] - th - padding * 3
        text_y = bar_y + padding
    elif position == "top":
        bar_y = 0
        text_y = padding
    else:
        bar_y = (RESOLUTION[1] - th) // 2 - padding
        text_y = bar_y + padding
    
    overlay_draw.rectangle(
        [(0, bar_y), (RESOLUTION[0], bar_y + th + padding * 2)],
        fill=(0, 0, 0, 160)
    )
    
    text_x = (RESOLUTION[0] - tw) // 2
    overlay_draw.text((text_x, text_y), text, fill=text_color, font=font)
    
    # Composite
    img = img.convert("RGBA")
    result = Image.alpha_composite(img, overlay)
    result.convert("RGB").save(output_path, quality=95)
    return output_path


def image_to_video(image_path, output_path, duration=5, audio_path=None):
    """Convert a static image to a video clip, optionally with audio."""
    args = ["-loop", "1", "-i", image_path]
    
    if audio_path:
        args += ["-i", audio_path]
        duration = get_audio_duration(audio_path)
    
    args += [
        "-c:v", "libx264", "-preset", "fast", "-crf", "23",
        "-t", str(duration),
        "-pix_fmt", "yuv420p",
        "-r", "24",
    ]
    
    if audio_path:
        args += ["-c:a", "aac", "-b:a", "128k", "-shortest"]
    
    args.append(output_path)
    run_ffmpeg(args)
    return output_path


def slideshow(images, audio=None, output="slideshow.mp4", duration_per_image=5,
              title=None, subtitle=None):
    """Create a slideshow from images with optional audio narration."""
    if not images:
        print("No images provided", file=sys.stderr)
        sys.exit(1)
    
    if audio:
        total_duration = get_audio_duration(audio)
        dur_per_img = total_duration / len(images)
    else:
        dur_per_img = duration_per_image
        total_duration = dur_per_img * len(images)
    
    tmp_dir = tempfile.mkdtemp(prefix="argus_slide_")
    
    try:
        # Process images: resize + optional title overlay
        processed = []
        for i, img_path in enumerate(images):
            out_img = os.path.join(tmp_dir, f"slide_{i:03d}.jpg")
            
            if title and i == 0:
                render_overlay_image(img_path, title, out_img, position="top")
            else:
                img = Image.open(img_path).convert("RGB").resize(RESOLUTION, Image.LANCZOS)
                img.save(out_img, quality=95)
            processed.append(out_img)
        
        # Create concat file
        concat_file = os.path.join(tmp_dir, "concat.txt")
        with open(concat_file, "w") as f:
            for img in processed:
                f.write(f"file '{img}'\n")
                f.write(f"duration {dur_per_img}\n")
            f.write(f"file '{processed[-1]}'\n")
        
        args = ["-f", "concat", "-safe", "0", "-i", concat_file]
        
        if audio:
            args += ["-i", audio]
        
        args += [
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-pix_fmt", "yuv420p", "-r", "24",
        ]
        
        if audio:
            args += ["-c:a", "aac", "-b:a", "128k", "-shortest"]
        else:
            args += ["-t", str(total_duration)]
        
        args.append(output)
        run_ffmpeg(args)
        
        size = os.path.getsize(output)
        print(f"Slideshow saved: {output} ({total_duration:.1f}s, {len(images)} images, {size/1024/1024:.1f}MB)")
        return output
    finally:
        for f in os.listdir(tmp_dir):
            os.unlink(os.path.join(tmp_dir, f))
        os.rmdir(tmp_dir)


def overlay(image, text, audio=None, output="overlay.mp4", duration=5, position="bottom"):
    """Create a video from image with text overlay and optional audio."""
    tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    try:
        render_overlay_image(image, text, tmp.name, position=position)
        if audio:
            duration = get_audio_duration(audio)
        image_to_video(tmp.name, output, duration, audio)
        print(f"Overlay video saved: {output} ({duration:.1f}s)")
        return output
    finally:
        os.unlink(tmp.name)


def stitch(clips, output="stitched.mp4"):
    """Stitch multiple video clips together."""
    if len(clips) == 1:
        subprocess.run(["cp", clips[0], output])
        return output
    
    concat_file = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
    try:
        for clip in clips:
            concat_file.write(f"file '{os.path.abspath(clip)}'\n")
        concat_file.close()
        
        run_ffmpeg([
            "-f", "concat", "-safe", "0", "-i", concat_file.name,
            "-c:v", "libx264", "-preset", "fast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k",
            "-pix_fmt", "yuv420p",
            output
        ])
        
        dur = get_audio_duration(output)
        print(f"Stitched: {output} ({dur:.1f}s, {len(clips)} clips)")
        return output
    finally:
        os.unlink(concat_file.name)


def create_title_card(text, output, duration=3, subtitle=None, bg_color=(26, 26, 46)):
    """Create a title card video."""
    tmp = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
    try:
        render_text_image(text, tmp.name, bg_color=bg_color, font_size=48,
                         subtitle=subtitle, subtitle_size=28)
        image_to_video(tmp.name, output, duration)
        print(f"Title card saved: {output} ({duration}s)")
        return output
    finally:
        os.unlink(tmp.name)


def generate_briefing_video(sections, audio_path, output="briefing.mp4"):
    """Generate a morning briefing video from section data + narration audio.
    
    sections: list of dicts with keys:
        - title: section title (required)
        - image: path to image (optional)
        - text: overlay text (optional)
    """
    tmp_dir = tempfile.mkdtemp(prefix="argus_briefing_")
    clips = []
    
    try:
        total_duration = get_audio_duration(audio_path)
        title_dur = 3
        remaining = total_duration - title_dur
        time_per_section = remaining / max(len(sections), 1)
        
        # Title card
        title_path = os.path.join(tmp_dir, "title.mp4")
        create_title_card(
            "Argus Daily Briefing",
            title_path,
            duration=title_dur,
            subtitle=time.strftime("%A, %B %d, %Y")
        )
        clips.append(title_path)
        
        # Section clips
        for i, section in enumerate(sections):
            clip_path = os.path.join(tmp_dir, f"section_{i}.mp4")
            
            if section.get("image") and os.path.exists(section["image"]):
                overlay(
                    image=section["image"],
                    text=section.get("text", section["title"]),
                    output=clip_path,
                    duration=time_per_section,
                    position="bottom"
                )
            else:
                create_title_card(
                    section["title"],
                    clip_path,
                    duration=time_per_section,
                    subtitle=section.get("text", "")[:120]
                )
            clips.append(clip_path)
        
        # Stitch clips
        stitched = os.path.join(tmp_dir, "stitched.mp4")
        stitch(clips, stitched)
        
        # Mux narration audio
        run_ffmpeg([
            "-i", stitched, "-i", audio_path,
            "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
            "-map", "0:v:0", "-map", "1:a:0",
            "-shortest", output
        ])
        
        dur = get_audio_duration(output)
        size = os.path.getsize(output)
        print(f"Briefing video saved: {output} ({dur:.1f}s, {size/1024/1024:.1f}MB)")
        return output
    finally:
        for f in os.listdir(tmp_dir):
            os.unlink(os.path.join(tmp_dir, f))
        os.rmdir(tmp_dir)


def main():
    parser = argparse.ArgumentParser(description="Argus Video Composer")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # Slideshow
    sl = subparsers.add_parser("slideshow")
    sl.add_argument("--images", nargs="+", required=True)
    sl.add_argument("--audio")
    sl.add_argument("--output", "-o", default="slideshow.mp4")
    sl.add_argument("--duration", type=float, default=5)
    sl.add_argument("--title")
    sl.add_argument("--subtitle")
    
    # Overlay
    ov = subparsers.add_parser("overlay")
    ov.add_argument("--image", required=True)
    ov.add_argument("--text", required=True)
    ov.add_argument("--audio")
    ov.add_argument("--output", "-o", default="overlay.mp4")
    ov.add_argument("--duration", type=float, default=5)
    ov.add_argument("--position", default="bottom", choices=["top", "center", "bottom"])
    
    # Stitch
    st = subparsers.add_parser("stitch")
    st.add_argument("--clips", nargs="+", required=True)
    st.add_argument("--output", "-o", default="stitched.mp4")
    
    # Title card
    tc = subparsers.add_parser("title")
    tc.add_argument("text")
    tc.add_argument("--output", "-o", default="title.mp4")
    tc.add_argument("--duration", type=float, default=3)
    tc.add_argument("--subtitle")
    
    # Briefing video
    bv = subparsers.add_parser("briefing")
    bv.add_argument("--sections-json", required=True)
    bv.add_argument("--audio", required=True)
    bv.add_argument("--output", "-o", default="briefing.mp4")
    
    args = parser.parse_args()
    
    if args.command == "slideshow":
        slideshow(args.images, args.audio, args.output, args.duration,
                 title=args.title, subtitle=args.subtitle)
    elif args.command == "overlay":
        overlay(args.image, args.text, args.audio, args.output, args.duration, args.position)
    elif args.command == "stitch":
        stitch(args.clips, args.output)
    elif args.command == "title":
        create_title_card(args.text, args.output, args.duration, subtitle=args.subtitle)
    elif args.command == "briefing":
        with open(args.sections_json) as f:
            sections = json.load(f)
        generate_briefing_video(sections, args.audio, args.output)


if __name__ == "__main__":
    main()
