---
name: argusai
description: Query ArgusAI security camera events, check camera status, and get activity summaries. Use when asked about security cameras, deliveries, who's at the door, or home activity.
triggers:
  - camera
  - cameras
  - security
  - driveway
  - front door
  - back door
  - doorbell
  - package
  - delivery
  - visitor
  - anyone at
  - motion
  - activity
---

# ArgusAI Skill

Query the ArgusAI security camera system for events, camera status, and activity.

## Quick Query (NLU)

For natural language queries, use the NLU script:

```bash
# Natural language queries
python skills/argusai/argusai_nlu.py "is anyone at the front door?"
python skills/argusai/argusai_nlu.py "any packages today?"
python skills/argusai/argusai_nlu.py "what's happening in the driveway?"
python skills/argusai/argusai_nlu.py "security status"
python skills/argusai/argusai_nlu.py "how many cameras do I have?"

# Show detected intent
python skills/argusai/argusai_nlu.py --intent "check the back door"

# JSON output
python skills/argusai/argusai_nlu.py --json "any activity today?"
```

### Supported Intents

| Intent | Example Queries |
|--------|-----------------|
| `list_cameras` | "how many cameras?", "list cameras" |
| `status` | "security status", "what's the status?" |
| `check_location` | "is anyone at the front door?", "check the driveway" |
| `recent_events` | "any activity today?", "what happened?" |
| `packages` | "any packages?", "deliveries today?" |
| `doorbell` | "did the doorbell ring?", "any visitors?" |
| `persons` | "did you see anyone?", "any people detected?" |

### Location Aliases

The NLU understands these location aliases:

| Say | Maps to |
|-----|---------|
| "front door", "doorbell", "entrance" | Front Door |
| "back door", "backyard", "rear" | Back Door |
| "driveway", "drive", "garage", "street" | Driveway |

## Connection

```bash
# Use IP for reliability (DNS: argusai.bengtson.local -> 10.0.1.46)
ARGUSAI_URL="https://10.0.1.46:3000/api/v1"
ARGUSAI_KEY=$(security find-generic-password -a argus -s argusai-api-key -w)
```

## Cameras

| Name | ID | Type |
|------|-----|------|
| Back Door | `2b0887a3-3fae-4fd9-b64b-910a18df5d7d` | Camera |
| Driveway | `6470859b-5fbb-410b-8570-d8f82cf01797` | Camera |
| Front Door | `fd474199-bb51-4848-b8d4-39cf9b9e30ff` | Doorbell |

## Common Queries

### Recent events (any camera)
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/events?limit=10" | jq '.events[] | {time: .timestamp, camera: .camera_name, desc: .description, confidence: .confidence}'
```

### Events by camera name
First map name to ID, then query:
```bash
# Front Door events
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/events?camera_id=fd474199-bb51-4848-b8d4-39cf9b9e30ff&limit=10"
```

### Today's events
```bash
TODAY=$(date -u +%Y-%m-%dT00:00:00Z)
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/events?since=$TODAY&limit=50"
```

### Package deliveries
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/events?limit=50" | \
  jq '[.events[] | select(.objects_detected | contains(["package"]))]'
```

### Person detections
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/events?limit=20" | \
  jq '[.events[] | select(.objects_detected | contains(["person"]))]'
```

### Doorbell rings
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/events?limit=50" | \
  jq '[.events[] | select(.is_doorbell_ring == true)]'
```

### Camera status
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/cameras" | \
  jq '.[] | {name, is_enabled, source_type}'
```

### Protect controller status
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/protect/controllers" | \
  jq '.data[] | {name, is_connected, last_error}'
```

### Storage stats
```bash
curl -sk -H "X-API-Key: $ARGUSAI_KEY" "$ARGUSAI_URL/system/storage"
```

## Response Format

Events include:
- `timestamp` — When it happened
- `camera_name` — Which camera
- `description` — AI-generated description of what happened
- `confidence` — 0-100 confidence score
- `objects_detected` — Array: person, vehicle, package, animal
- `is_doorbell_ring` — Boolean for doorbell events
- `entity_name` — Recognized entity if matched

## Example Responses

**Status check:** "All 3 cameras online. 15 events today, 2 packages delivered."

**Front door query:** "3 events at Front Door today: doorbell at 2:15 PM (person in dark jacket), package delivery at 11:30 AM, mail carrier at 9:45 AM."

**Delivery check:** "Yes, 2 packages delivered: FedEx at 11:30 AM (front), Amazon at 5:04 PM (back door)."

## Webhook Integration

Real-time alerts are sent to OpenClaw via webhook:
- **Endpoint:** `https://10.0.1.32:18789/hooks/argusai`
- **Alert Rule:** "OpenClaw - All Events" (person + package, ≥70% confidence)
- **Transform:** `~/.openclaw/hooks/argusai-transform.js`
- **Delivery:** Telegram → Brent (chat ID 8310835415)

Trigger test:
```bash
curl -sk -X POST "https://10.0.1.32:18789/hooks/argusai" \
  -H "Authorization: Bearer c5f62ff21092d77fb5c49060a43395607e46f1f2a8653df7" \
  -H "Content-Type: application/json" \
  -d '{"event_id":"test","camera":{"name":"Front Door"},"description":"Test event","confidence":95,"objects_detected":["person"]}'
```

## Notes

- All timestamps are UTC in API, convert to CST (America/Chicago) for display
- Confidence below 70 = mention uncertainty
- Thumbnail URLs require same API key auth
- Use jq to filter/format JSON responses
