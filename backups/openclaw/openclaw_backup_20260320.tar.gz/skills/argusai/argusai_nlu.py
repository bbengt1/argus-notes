#!/usr/bin/env python3
"""ArgusAI NLU - Natural Language Understanding for security camera queries.

Provides intent detection, location extraction, and conversational responses
for the ArgusAI security camera system.

Usage:
    python argusai_nlu.py "is anyone at the front door?"
    python argusai_nlu.py --intent "check the driveway"
    python argusai_nlu.py --query "any packages today?"
"""

import argparse
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import ssl


# Configuration
# Use IP directly for reliability (DNS: argusai.bengtson.local -> 10.0.1.46)
ARGUSAI_URL = os.environ.get("ARGUSAI_URL", "https://10.0.1.46:3000/api/v1")
ARGUSAI_KEY = os.environ.get("ARGUSAI_KEY") or subprocess.check_output(
    ["security", "find-generic-password", "-a", "argus", "-s", "argusai-api-key", "-w"],
    text=True
).strip()

# Camera mapping (name variations -> canonical name)
CAMERA_ALIASES = {
    "front door": "Front Door",
    "front": "Front Door",
    "doorbell": "Front Door",
    "entrance": "Front Door",
    "back door": "Back Door",
    "back": "Back Door",
    "rear": "Back Door",
    "backyard": "Back Door",
    "driveway": "Driveway",
    "drive": "Driveway",
    "garage": "Driveway",
    "street": "Driveway",
}


class Intent(Enum):
    """Detected user intents."""
    LIST_CAMERAS = "list_cameras"
    STATUS = "status"
    CHECK_LOCATION = "check_location"
    RECENT_EVENTS = "recent_events"
    PACKAGES = "packages"
    DOORBELL = "doorbell"
    PERSONS = "persons"
    UNKNOWN = "unknown"


def api_request(endpoint: str, params: dict[str, Any] | None = None) -> dict | list | None:
    """Make a request to the ArgusAI API."""
    url = f"{ARGUSAI_URL}{endpoint}"
    if params:
        query = "&".join(f"{k}={v}" for k, v in params.items())
        url = f"{url}?{query}"
    
    # Create SSL context that ignores cert verification for local dev
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    req = Request(url, headers={"X-API-Key": ARGUSAI_KEY})
    try:
        with urlopen(req, context=ctx, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except (HTTPError, URLError, json.JSONDecodeError) as e:
        print(f"API error: {e}", file=sys.stderr)
        return None


def get_cameras() -> list[dict]:
    """Fetch all cameras."""
    data = api_request("/cameras")
    return data if isinstance(data, list) else []


def get_events(camera_id: str | None = None, limit: int = 10) -> list[dict]:
    """Fetch recent events."""
    params = {"limit": limit}
    if camera_id:
        params["camera_id"] = camera_id
    data = api_request("/events", params)
    if isinstance(data, dict):
        return data.get("events", [])
    return data if isinstance(data, list) else []


def find_camera(name: str) -> dict | None:
    """Find a camera by name with fuzzy matching."""
    name_lower = name.lower().strip()
    
    # Check aliases first
    canonical = CAMERA_ALIASES.get(name_lower)
    if canonical:
        name_lower = canonical.lower()
    
    cameras = get_cameras()
    
    # Exact match
    for cam in cameras:
        if cam.get("name", "").lower() == name_lower:
            return cam
    
    # Partial match
    for cam in cameras:
        cam_name = cam.get("name", "").lower()
        if name_lower in cam_name or cam_name in name_lower:
            return cam
    
    return None


def format_time_ago(timestamp_str: str) -> str:
    """Format a timestamp as relative time."""
    try:
        # Parse ISO timestamp - handle both with and without timezone
        ts = timestamp_str.replace("Z", "+00:00")
        if "+" not in ts and "-" not in ts[10:]:  # No timezone info
            # Assume UTC
            dt = datetime.fromisoformat(ts).replace(tzinfo=timezone.utc)
        else:
            dt = datetime.fromisoformat(ts)
        
        now = datetime.now(timezone.utc)
        diff = now - dt
        
        seconds = diff.total_seconds()
        if seconds < 0:
            return "just now"  # Future timestamp, treat as now
        elif seconds < 60:
            return "just now"
        elif seconds < 3600:
            minutes = int(seconds / 60)
            return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
        elif seconds < 86400:
            hours = int(seconds / 3600)
            return f"{hours} hour{'s' if hours != 1 else ''} ago"
        else:
            days = int(seconds / 86400)
            return f"{days} day{'s' if days != 1 else ''} ago"
    except (ValueError, TypeError) as e:
        print(f"Time parse error: {e}", file=sys.stderr)
        return "recently"


def format_time_local(timestamp_str: str) -> str:
    """Format timestamp in local time (12-hour format)."""
    try:
        ts = timestamp_str.replace("Z", "+00:00")
        dt = datetime.fromisoformat(ts)
        # Convert to local (CST)
        from datetime import timedelta
        local_dt = dt - timedelta(hours=6)  # UTC to CST
        return local_dt.strftime("%-I:%M %p")
    except (ValueError, TypeError):
        return "unknown time"


def extract_location(text: str) -> str | None:
    """Extract a camera location from natural language."""
    text_lower = text.lower()
    
    # Direct location keywords
    locations = [
        "front door", "back door", "driveway", "backyard", "front yard",
        "garage", "porch", "patio", "entrance", "doorbell",
    ]
    for loc in locations:
        if loc in text_lower:
            return loc
    
    # Pattern: "the X camera"
    patterns = [
        r"(?:the |my )?(\w+(?:\s+\w+)?)\s+camera",
        r"camera\s+(?:at|on|in|for)\s+(?:the\s+)?(\w+(?:\s+\w+)?)",
        r"(?:at|on|in)\s+(?:the\s+)?(\w+(?:\s+\w+)?)\s*\??$",
    ]
    for pattern in patterns:
        if match := re.search(pattern, text_lower):
            return match.group(1).strip()
    
    return None


def detect_intent(text: str) -> tuple[Intent, str | None]:
    """Detect the user's intent from natural language.
    
    Returns:
        Tuple of (intent, location/camera_name or None)
    """
    text_lower = text.lower()
    location = extract_location(text)
    
    # List cameras
    list_phrases = [
        "how many cameras", "list cameras", "show cameras", 
        "what cameras", "which cameras", "all cameras", "my cameras"
    ]
    if any(phrase in text_lower for phrase in list_phrases):
        return (Intent.LIST_CAMERAS, None)
    
    # General status
    if "status" in text_lower or "security status" in text_lower:
        return (Intent.STATUS, None)
    
    # Packages specifically
    package_phrases = ["package", "delivery", "deliveries", "delivered"]
    if any(phrase in text_lower for phrase in package_phrases):
        return (Intent.PACKAGES, location)
    
    # Doorbell specifically
    doorbell_phrases = ["doorbell", "rang", "ring", "ding"]
    if any(phrase in text_lower for phrase in doorbell_phrases):
        return (Intent.DOORBELL, location)
    
    # Person detection
    person_phrases = ["visitor", "visitors", "person", "people", "someone", "anyone"]
    if any(phrase in text_lower for phrase in person_phrases):
        if location:
            return (Intent.CHECK_LOCATION, location)
        return (Intent.PERSONS, None)
    
    # Check specific location
    check_phrases = [
        "what's happening", "what is happening", "going on",
        "check", "look at", "show me", "see", "activity",
        "is there", "any motion", "any movement",
    ]
    if location and any(phrase in text_lower for phrase in check_phrases):
        return (Intent.CHECK_LOCATION, location)
    
    # Questions about locations
    if location and any(q in text_lower for q in ["what", "who", "is there", "any"]):
        return (Intent.CHECK_LOCATION, location)
    
    # Recent events
    event_phrases = [
        "any events", "recent events", "what happened", "what did you see",
        "any alerts", "notifications", "detected anything",
        "any activity", "anything unusual", "anything suspicious", "today",
    ]
    if any(phrase in text_lower for phrase in event_phrases):
        return (Intent.RECENT_EVENTS, location)
    
    # If location mentioned, default to checking it
    if location:
        return (Intent.CHECK_LOCATION, location)
    
    # Default to status
    return (Intent.STATUS, None)


def handle_list_cameras() -> str:
    """List all cameras."""
    cameras = get_cameras()
    
    if not cameras:
        return "No cameras are configured in ArgusAI."
    
    active = [c for c in cameras if c.get("is_enabled")]
    inactive = [c for c in cameras if not c.get("is_enabled")]
    
    response = f"You have {len(cameras)} camera{'s' if len(cameras) != 1 else ''}. "
    if active:
        names = ", ".join(c.get("name", "Unknown") for c in active)
        response += f"{len(active)} active: {names}. "
    if inactive:
        names = ", ".join(c.get("name", "Unknown") for c in inactive)
        response += f"{len(inactive)} inactive: {names}."
    
    return response.strip()


def handle_status() -> str:
    """Get overall security status."""
    cameras = get_cameras()
    events = get_events(limit=5)
    
    active_count = sum(1 for c in cameras if c.get("is_enabled"))
    response = f"Security status: {active_count} of {len(cameras)} cameras active. "
    
    if events:
        latest = events[0]
        time_ago = format_time_ago(latest.get("timestamp", ""))
        camera = latest.get("camera_name", "unknown camera")
        desc = latest.get("description", "activity detected")
        response += f"Latest: {camera} {time_ago} — {desc}"
    else:
        response += "No recent events detected."
    
    return response


def handle_check_location(location: str) -> str:
    """Check events at a specific camera location."""
    camera = find_camera(location)
    
    if not camera:
        return f"I couldn't find a camera for '{location}'. Try: Front Door, Back Door, or Driveway."
    
    camera_name = camera.get("name", "Unknown")
    camera_id = camera.get("id")
    events = get_events(camera_id=camera_id, limit=5)
    
    if not events:
        status = "active" if camera.get("is_enabled") else "inactive"
        return f"No recent events at {camera_name}. Camera is {status}."
    
    # Summarize events
    response = f"Recent activity at {camera_name}: "
    for evt in events[:3]:
        time_ago = format_time_ago(evt.get("timestamp", ""))
        desc = evt.get("description", "motion detected")
        # Truncate long descriptions
        if len(desc) > 80:
            desc = desc[:77] + "..."
        response += f"{time_ago}: {desc}. "
    
    if len(events) > 3:
        response += f"Plus {len(events) - 3} more."
    
    return response.strip()


def handle_recent_events(location: str | None = None) -> str:
    """Get recent events, optionally filtered by location."""
    camera_id = None
    if location:
        camera = find_camera(location)
        if camera:
            camera_id = camera.get("id")
    
    events = get_events(camera_id=camera_id, limit=10)
    
    if not events:
        if location:
            return f"No recent events at {location}."
        return "No recent security events across your cameras."
    
    response = "Recent events: "
    for evt in events[:5]:
        time_ago = format_time_ago(evt.get("timestamp", ""))
        camera = evt.get("camera_name", "Unknown")
        desc = evt.get("description", "activity")
        if len(desc) > 60:
            desc = desc[:57] + "..."
        response += f"{camera} ({time_ago}): {desc}. "
    
    if len(events) > 5:
        response += f"Plus {len(events) - 5} more event{'s' if len(events) - 5 != 1 else ''}."
    
    return response.strip()


def handle_packages() -> str:
    """Check for package deliveries."""
    events = get_events(limit=50)
    
    # Filter for package events
    package_events = [
        e for e in events 
        if "package" in (e.get("objects_detected") or [])
        or "package" in e.get("description", "").lower()
        or "delivery" in e.get("description", "").lower()
    ]
    
    if not package_events:
        return "No package deliveries detected recently."
    
    response = f"{len(package_events)} package event{'s' if len(package_events) != 1 else ''}: "
    for evt in package_events[:3]:
        time_local = format_time_local(evt.get("timestamp", ""))
        camera = evt.get("camera_name", "Unknown")
        response += f"{camera} at {time_local}. "
    
    if len(package_events) > 3:
        response += f"Plus {len(package_events) - 3} more."
    
    return response.strip()


def handle_doorbell() -> str:
    """Check for doorbell events."""
    events = get_events(limit=50)
    
    # Filter for doorbell events
    doorbell_events = [e for e in events if e.get("is_doorbell_ring")]
    
    if not doorbell_events:
        return "No doorbell rings detected recently."
    
    response = f"{len(doorbell_events)} doorbell event{'s' if len(doorbell_events) != 1 else ''}: "
    for evt in doorbell_events[:3]:
        time_local = format_time_local(evt.get("timestamp", ""))
        desc = evt.get("description", "someone at the door")
        if len(desc) > 50:
            desc = desc[:47] + "..."
        response += f"{time_local}: {desc}. "
    
    return response.strip()


def handle_persons() -> str:
    """Check for person detections."""
    events = get_events(limit=30)
    
    # Filter for person events
    person_events = [
        e for e in events 
        if "person" in (e.get("objects_detected") or [])
    ]
    
    if not person_events:
        return "No people detected recently."
    
    response = f"{len(person_events)} person detection{'s' if len(person_events) != 1 else ''}: "
    for evt in person_events[:3]:
        time_ago = format_time_ago(evt.get("timestamp", ""))
        camera = evt.get("camera_name", "Unknown")
        desc = evt.get("description", "person detected")
        if len(desc) > 50:
            desc = desc[:47] + "..."
        response += f"{camera} ({time_ago}): {desc}. "
    
    if len(person_events) > 3:
        response += f"Plus {len(person_events) - 3} more."
    
    return response.strip()


def process_query(query: str) -> str:
    """Process a natural language query and return a response."""
    intent, location = detect_intent(query)
    
    match intent:
        case Intent.LIST_CAMERAS:
            return handle_list_cameras()
        case Intent.STATUS:
            return handle_status()
        case Intent.CHECK_LOCATION:
            return handle_check_location(location or "")
        case Intent.RECENT_EVENTS:
            return handle_recent_events(location)
        case Intent.PACKAGES:
            return handle_packages()
        case Intent.DOORBELL:
            return handle_doorbell()
        case Intent.PERSONS:
            return handle_persons()
        case _:
            return handle_status()


def main():
    parser = argparse.ArgumentParser(description="ArgusAI Natural Language Query")
    parser.add_argument("query", nargs="*", help="Natural language query")
    parser.add_argument("--intent", action="store_true", help="Show detected intent")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()
    
    query = " ".join(args.query) if args.query else "security status"
    
    if args.intent:
        intent, location = detect_intent(query)
        result = {"intent": intent.value, "location": location}
        if args.json:
            print(json.dumps(result))
        else:
            print(f"Intent: {intent.value}")
            if location:
                print(f"Location: {location}")
        return
    
    response = process_query(query)
    
    if args.json:
        print(json.dumps({"query": query, "response": response}))
    else:
        print(response)


if __name__ == "__main__":
    main()
