---
name: home-assistant
description: Control smart home devices via Home Assistant. Turn lights on/off, dim, check status, activate scenes.
triggers:
  - turn on
  - turn off
  - lights
  - light
  - switch
  - dim
  - brighten
  - scene
  - thermostat
  - home assistant
---

# Home Assistant Skill

Control smart home devices via the Home Assistant REST API.

## Quick Start

```bash
# Natural language commands
python3 skills/home-assistant/ha_control.py "turn on the office lights"
python3 skills/home-assistant/ha_control.py "dim the wled to 30%"
python3 skills/home-assistant/ha_control.py "what's the status of the fishtank?"
python3 skills/home-assistant/ha_control.py "turn off the kennel light"

# Direct commands
python3 skills/home-assistant/ha_control.py on light.wled
python3 skills/home-assistant/ha_control.py off switch.hw01_fishtank
python3 skills/home-assistant/ha_control.py scene scene.feed_the_cats

# List devices
python3 skills/home-assistant/ha_control.py list lights
python3 skills/home-assistant/ha_control.py list switches
python3 skills/home-assistant/ha_control.py list all
```

## Connection

```bash
# IP for reliability (DNS: hassio.bengtson.local -> 10.0.1.233)
HA_URL="http://10.0.1.233:8123"
HA_TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

## Available Devices

### Lights
| Name | Entity ID | Notes |
|------|-----------|-------|
| Floor Lamp Office 1 | `light.floor_lamp_office_1` | Dimmable |
| Floor Lamp Office 2 | `light.floor_lamp_office_2` | Dimmable |
| WLED | `light.wled` | LED strip, RGB |
| BO05-KENNEL | `light.bo05_desklamp` | Kennel light |

### Switches
| Name | Entity ID | Notes |
|------|-----------|-------|
| HW01-FISHTANK | `switch.hw01_fishtank` | Fish tank |
| FM02-SHELF | `switch.fm02_shelf` | Shelf light |
| LR02-ENTLIGHT | `switch.lr02_entlight` | Entry light |

### Scenes
| Name | Entity ID |
|------|-----------|
| Feed the cats | `scene.feed_the_cats` |

## Device Aliases

The NLU understands these aliases:

| Say | Device |
|-----|--------|
| "office lights", "office", "floor lamp" | Floor Lamp Office 1 |
| "wled", "led strip", "led" | WLED |
| "kennel", "dog light" | BO05-KENNEL |
| "fishtank", "fish tank", "fish" | HW01-FISHTANK |
| "shelf", "shelf light" | FM02-SHELF |
| "entry light", "entryway" | LR02-ENTLIGHT |
| "feed cats", "cat feeder" | scene.feed_the_cats |

## Supported Commands

| Command | Example |
|---------|---------|
| Turn on | "turn on the office lights" |
| Turn off | "turn off the wled" |
| Toggle | "toggle the kennel light" |
| Dim | "dim the office lights to 30%" |
| Brighten | "brighten the wled" |
| Status | "what's the status of the fishtank?" |
| Scene | "activate feed the cats" |

## API Reference

```bash
# List all states
curl -s -H "Authorization: Bearer $HA_TOKEN" "$HA_URL/api/states" | jq

# Get specific device
curl -s -H "Authorization: Bearer $HA_TOKEN" "$HA_URL/api/states/light.wled" | jq

# Turn on a light
curl -s -X POST -H "Authorization: Bearer $HA_TOKEN" \
  -H "Content-Type: application/json" \
  "$HA_URL/api/services/light/turn_on" \
  -d '{"entity_id": "light.wled"}'

# Set brightness
curl -s -X POST -H "Authorization: Bearer $HA_TOKEN" \
  -H "Content-Type: application/json" \
  "$HA_URL/api/services/light/turn_on" \
  -d '{"entity_id": "light.wled", "brightness_pct": 50}'
```
