#!/usr/bin/env python3
"""Home Assistant Control - Smart home automation via HA REST API.

Control lights, switches, scenes, and more through Home Assistant.

Usage:
    python ha_control.py list lights
    python ha_control.py list switches
    python ha_control.py "turn on the office lights"
    python ha_control.py on light.floor_lamp_office_1
    python ha_control.py off switch.hw01_fishtank
    python ha_control.py scene scene.feed_the_cats
"""

import argparse
import json
import os
import re
import ssl
import subprocess
import sys
from dataclasses import dataclass
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


# Configuration
# Use IP for reliability (DNS: hassio.bengtson.local -> 10.0.1.233)
HA_URL = os.environ.get("HA_URL", "http://10.0.1.233:8123")
HA_TOKEN = os.environ.get("HA_TOKEN") or subprocess.check_output(
    ["security", "find-generic-password", "-a", "argus", "-s", "homeassistant-token", "-w"],
    text=True
).strip()

# Device name aliases for fuzzy matching
DEVICE_ALIASES = {
    # Lights (prioritize lights for common names)
    "office light": "light.floor_lamp_office_1",
    "office lights": "light.floor_lamp_office_1",
    "office lamp": "light.floor_lamp_office_1",
    "office": "light.floor_lamp_office_1",
    "floor lamp": "light.floor_lamp_office_1",
    "floor lamp 1": "light.floor_lamp_office_1",
    "floor lamp 2": "light.floor_lamp_office_2",
    "wled": "light.wled",
    "led strip": "light.wled",
    "led": "light.wled",
    "kennel light": "light.bo05_desklamp",
    "kennel": "light.bo05_desklamp",
    "dog light": "light.bo05_desklamp",
    "desk lamp": "light.yeelight_color4_0x1303bd01",
    
    # Switches
    "fishtank": "switch.hw01_fishtank",
    "fish tank": "switch.hw01_fishtank",
    "fish": "switch.hw01_fishtank",
    "shelf": "switch.fm02_shelf",
    "shelf light": "switch.fm02_shelf",
    "entry light": "switch.lr02_entlight",
    "entryway": "switch.lr02_entlight",
    "entryway light": "switch.lr02_entlight",
    
    # Scenes
    "feed cats": "scene.feed_the_cats",
    "cat feeder": "scene.feed_the_cats",
    "feed the cats": "scene.feed_the_cats",
}


@dataclass
class Device:
    """A Home Assistant device."""
    entity_id: str
    name: str
    state: str
    domain: str
    attributes: dict[str, Any]
    
    @property
    def is_on(self) -> bool:
        return self.state in ("on", "playing", "open", "unlocked", "home")
    
    @property
    def is_available(self) -> bool:
        return self.state != "unavailable"


def api_request(method: str, endpoint: str, data: dict | None = None) -> dict | list | None:
    """Make a request to the Home Assistant API."""
    url = f"{HA_URL}/api/{endpoint}"
    headers = {
        "Authorization": f"Bearer {HA_TOKEN}",
        "Content-Type": "application/json",
    }
    
    req = Request(url, headers=headers, method=method)
    if data:
        req.data = json.dumps(data).encode()
    
    try:
        with urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except (HTTPError, URLError, json.JSONDecodeError) as e:
        print(f"API error: {e}", file=sys.stderr)
        return None


def get_states() -> list[Device]:
    """Fetch all device states."""
    data = api_request("GET", "states")
    if not data:
        return []
    
    devices = []
    for item in data:
        entity_id = item.get("entity_id", "")
        domain = entity_id.split(".")[0] if "." in entity_id else ""
        devices.append(Device(
            entity_id=entity_id,
            name=item.get("attributes", {}).get("friendly_name", entity_id),
            state=item.get("state", "unknown"),
            domain=domain,
            attributes=item.get("attributes", {}),
        ))
    return devices


def get_device(entity_id: str) -> Device | None:
    """Get a specific device by entity_id."""
    data = api_request("GET", f"states/{entity_id}")
    if not data:
        return None
    
    domain = entity_id.split(".")[0] if "." in entity_id else ""
    return Device(
        entity_id=entity_id,
        name=data.get("attributes", {}).get("friendly_name", entity_id),
        state=data.get("state", "unknown"),
        domain=domain,
        attributes=data.get("attributes", {}),
    )


def find_device(query: str) -> Device | None:
    """Find a device by name with fuzzy matching."""
    query_lower = query.lower().strip()
    
    # Check aliases first
    if query_lower in DEVICE_ALIASES:
        entity_id = DEVICE_ALIASES[query_lower]
        return get_device(entity_id)
    
    # Check if it's already an entity_id
    if "." in query:
        return get_device(query)
    
    # Fuzzy match against all devices
    devices = get_states()
    
    # Exact name match
    for dev in devices:
        if dev.name.lower() == query_lower:
            return dev
    
    # Partial name match
    for dev in devices:
        if query_lower in dev.name.lower() or dev.name.lower() in query_lower:
            return dev
    
    # Entity ID partial match
    for dev in devices:
        entity_name = dev.entity_id.split(".")[-1].replace("_", " ")
        if query_lower in entity_name or entity_name in query_lower:
            return dev
    
    return None


def call_service(domain: str, service: str, entity_id: str, data: dict | None = None) -> bool:
    """Call a Home Assistant service."""
    payload = {"entity_id": entity_id}
    if data:
        payload.update(data)
    
    result = api_request("POST", f"services/{domain}/{service}", payload)
    return result is not None


def turn_on(entity_id: str, **kwargs) -> bool:
    """Turn on a device."""
    domain = entity_id.split(".")[0]
    return call_service(domain, "turn_on", entity_id, kwargs if kwargs else None)


def turn_off(entity_id: str) -> bool:
    """Turn off a device."""
    domain = entity_id.split(".")[0]
    return call_service(domain, "turn_off", entity_id)


def toggle(entity_id: str) -> bool:
    """Toggle a device."""
    domain = entity_id.split(".")[0]
    return call_service(domain, "toggle", entity_id)


def activate_scene(entity_id: str) -> bool:
    """Activate a scene."""
    return call_service("scene", "turn_on", entity_id)


def set_brightness(entity_id: str, brightness_pct: int) -> bool:
    """Set light brightness (0-100%)."""
    return turn_on(entity_id, brightness_pct=brightness_pct)


def list_devices(domain: str | None = None) -> list[Device]:
    """List devices, optionally filtered by domain."""
    devices = get_states()
    if domain:
        devices = [d for d in devices if d.domain == domain]
    # Filter out unavailable and uninteresting devices
    devices = [d for d in devices if d.is_available]
    return devices


# Natural language processing
def extract_device_and_action(text: str) -> tuple[str | None, str | None, dict]:
    """Extract device name and action from natural language."""
    text_lower = text.lower().strip()
    params = {}
    
    # Action patterns
    action = None
    if re.search(r"\b(turn on|switch on|enable|activate)\b", text_lower):
        action = "on"
    elif re.search(r"\b(turn off|switch off|disable|deactivate)\b", text_lower):
        action = "off"
    elif re.search(r"\btoggle\b", text_lower):
        action = "toggle"
    elif re.search(r"\bdim\b", text_lower):
        action = "dim"
        params["brightness_pct"] = 30
    elif re.search(r"\bbrighten\b", text_lower):
        action = "brighten"
        params["brightness_pct"] = 100
    elif re.search(r"\b(status|state|is .+ on|is .+ off|check)\b", text_lower):
        action = "status"
    
    # Brightness patterns
    if match := re.search(r"(\d+)\s*%", text_lower):
        params["brightness_pct"] = int(match.group(1))
        if not action:
            action = "on"
    
    if match := re.search(r"to\s+(\d+)", text_lower):
        params["brightness_pct"] = int(match.group(1))
        if not action:
            action = "on"
    
    # Extract device name (remove action words and filler)
    device_text = text_lower
    # Remove full phrases first
    remove_phrases = [
        "turn on", "turn off", "switch on", "switch off", 
        "what's the status of", "what is the status of", "status of", "state of",
        "what's", "what is", "is the", "are the",
    ]
    for phrase in remove_phrases:
        device_text = device_text.replace(phrase, " ")
    
    # Remove single words with word boundaries (to avoid mangling "office" -> "ice")
    remove_words = ["toggle", "dim", "brighten", "set", "check"]
    for word in remove_words:
        device_text = re.sub(rf"\b{word}\b", " ", device_text)
    
    # Remove trailing "on" or "off" with punctuation (e.g., "is the light on?")
    device_text = re.sub(r"\s+(on|off)\s*\??$", "", device_text)
    
    # Remove "to X%" patterns
    device_text = re.sub(r"\s+to\s+\d+\s*%?", "", device_text)
    
    # Remove "the" only as a standalone word
    device_text = re.sub(r"\bthe\b", " ", device_text)
    
    # Clean up
    device_text = re.sub(r"\d+\s*%?", "", device_text)
    device_text = device_text.replace("?", "")
    device_text = re.sub(r"\s+", " ", device_text).strip()
    
    return device_text if device_text else None, action, params


def process_command(text: str) -> str:
    """Process a natural language command."""
    device_query, action, params = extract_device_and_action(text)
    
    if not device_query:
        return "I couldn't understand which device you want to control."
    
    device = find_device(device_query)
    if not device:
        return f"I couldn't find a device matching '{device_query}'."
    
    if not action or action == "status":
        # Just report status
        status = "on" if device.is_on else "off"
        return f"{device.name} is currently {status}."
    
    # Execute action
    success = False
    if action == "on":
        if params.get("brightness_pct") and device.domain == "light":
            success = set_brightness(device.entity_id, params["brightness_pct"])
        else:
            success = turn_on(device.entity_id)
    elif action == "off":
        success = turn_off(device.entity_id)
    elif action == "toggle":
        success = toggle(device.entity_id)
    elif action in ("dim", "brighten"):
        if device.domain == "light":
            success = set_brightness(device.entity_id, params.get("brightness_pct", 50))
        else:
            return f"{device.name} doesn't support brightness control."
    
    if success:
        action_past = {"on": "turned on", "off": "turned off", "toggle": "toggled", "dim": "dimmed", "brighten": "brightened"}.get(action, action)
        extra = f" to {params['brightness_pct']}%" if params.get("brightness_pct") else ""
        return f"{device.name} {action_past}{extra}."
    else:
        return f"Failed to control {device.name}."


def main():
    parser = argparse.ArgumentParser(description="Home Assistant Control")
    parser.add_argument("command", nargs="*", help="Command or natural language query")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    args = parser.parse_args()
    
    if not args.command:
        print("Usage: ha_control.py <command>", file=sys.stderr)
        print("  list lights|switches|scenes|all")
        print("  on|off|toggle <entity_id or name>")
        print("  scene <scene_id>")
        print('  "natural language command"')
        sys.exit(1)
    
    cmd = args.command[0].lower()
    
    # List command
    if cmd == "list":
        domain = args.command[1] if len(args.command) > 1 else None
        if domain == "all":
            domain = None
        devices = list_devices(domain)
        
        if args.json:
            print(json.dumps([{"id": d.entity_id, "name": d.name, "state": d.state} for d in devices], indent=2))
        else:
            for d in devices:
                status = "✓" if d.is_on else "○"
                print(f"{status} {d.name} ({d.entity_id}) - {d.state}")
        return
    
    # Direct commands
    if cmd in ("on", "off", "toggle") and len(args.command) > 1:
        target = " ".join(args.command[1:])
        device = find_device(target)
        if not device:
            print(f"Device not found: {target}")
            sys.exit(1)
        
        if cmd == "on":
            success = turn_on(device.entity_id)
        elif cmd == "off":
            success = turn_off(device.entity_id)
        else:
            success = toggle(device.entity_id)
        
        if success:
            print(f"{device.name} {cmd}.")
        else:
            print(f"Failed to {cmd} {device.name}.")
        return
    
    if cmd == "scene" and len(args.command) > 1:
        scene_id = args.command[1]
        if not scene_id.startswith("scene."):
            scene_id = f"scene.{scene_id}"
        if activate_scene(scene_id):
            print(f"Scene activated: {scene_id}")
        else:
            print(f"Failed to activate scene: {scene_id}")
        return
    
    # Natural language command
    text = " ".join(args.command)
    response = process_command(text)
    print(response)


if __name__ == "__main__":
    main()
